# TypeMaster 11 — Typing Tutor Website

A TypingMaster 11–style touch-typing tutor. 100% static: HTML + CSS + vanilla JS,
zero dependencies, zero network calls. Works from `file://` or any static host.

## Run locally

Open `index.html` in a desktop browser, or:

```sh
cd ~/workspace/typemaster
python3 -m http.server 8471
# -> http://localhost:8471/
```

## What's inside

- `index.html` — app shell: blue title bar, left nav (Typing Course, Typing Test,
  Games, Statistics, Review), status bar
- `assets/css/style.css` — TypingMaster-11 desktop theme
- `assets/js/app.js` — hash router, course dashboard, on-screen keyboard with
  finger-zone colors + next-key hints
- `assets/js/data.js` — 12 lessons × 5 drills (new keys / key drill / word drill /
  sentence drill / review), seeded deterministic drill generator
- `assets/js/engine.js` — drill runner (per-char coloring, no-backspace like TM,
  live WPM/accuracy, 1–3 stars, per-key error logging)
- `assets/js/test.js` — 1/2/5/10-minute typing tests, certificate-style results,
  per-duration personal bests
- `assets/js/games.js` — Bubbles, WordTris, Clouds (canvas arcade games)
- `assets/js/stats.js` — session history, WPM/accuracy charts, problem-key
  heatmap, per-lesson stars, weak-key Review drills

Progress (stars, sessions, bests, error logs) is stored in `localStorage` under
the `tm11.*` prefix and survives reloads.

## Deploy (Netlify, free)

Drag-and-drop the `~/workspace/typemaster` folder onto
https://app.netlify.com/drop — done. No build step needed.

## Verified

2026-09-29: 24-assertion headless-Chromium E2E (`/tmp/e2e-tm11.mjs`) — all views
render, a full drill typed end-to-end (result panel, stars persist), typing test
live WPM + countdown, all three games mount and run, stats record sessions,
progress survives reload. Zero console/page errors.
