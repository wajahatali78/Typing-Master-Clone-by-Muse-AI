/* engine.js — practice drill runner + 'practice' view.
 * Loaded AFTER app.js (window.TM contract) and data.js (window.TMData).
 * Defines window.TM.Engine and registers TM view 'practice'.
 * Vanilla JS, no external requests, works from file://.
 */
(function () {
  'use strict';
  if (!window.TM) return; // app.js contract not present; nothing to register
  var TM = window.TM;

  /* Star thresholds per drill kind: 3 stars needs accuracy>=97 AND netWpm>=this. */
  var STAR_WPM = { newkeys: 15, keydrill: 15, worddrill: 20, sentence: 25, review: 25 };

  /* Minimal functional CSS injected once (colored chars, caret). The site's
   * own stylesheet (other workstream) can override these. */
  function ensureCss() {
    if (document.getElementById('tm-practice-css')) return;
    var s = document.createElement('style');
    s.id = 'tm-practice-css';
    s.textContent =
      '.tm-text{font-family:ui-monospace,Consolas,monospace;font-size:20px;line-height:2;' +
      'white-space:pre-wrap;word-break:break-word;background:#fff;border:1px solid #ddd;' +
      'border-radius:8px;padding:16px 18px;margin:12px 0;user-select:none;}' +
      '.tm-ok{color:#1a9e4b;}.tm-bad{color:#e5322d;background:#ffe3e1;border-radius:2px;}' +
      '.tm-caret{background:#cfe3ff;border-radius:2px;box-shadow:0 2px 0 #2b6cb0;}' +
      '.tm-nl{color:#9aa5b1;}' +
      '.tm-stats{display:flex;gap:18px;flex-wrap:wrap;font-size:14px;color:#444;margin:8px 0;}' +
      '.tm-stats b{color:#111;font-size:16px;}' +
      '.tm-hint{font-size:14px;color:#555;margin:6px 0;min-height:20px;}' +
      '.tm-controls{display:flex;gap:10px;align-items:center;margin:12px 0;flex-wrap:wrap;}' +
      '.tm-btn{cursor:pointer;border:1px solid #ccc;background:#f6f6f6;border-radius:6px;' +
      'padding:8px 16px;font-size:14px;}' +
      '.tm-btn.primary{background:#e5322d;border-color:#e5322d;color:#fff;}' +
      '.tm-result{background:#fff;border:1px solid #ddd;border-radius:8px;padding:20px;margin:12px 0;}' +
      '.tm-result table{border-collapse:collapse;margin:10px 0;}' +
      '.tm-result td{padding:4px 14px 4px 0;font-size:15px;}' +
      '.tm-stars{font-size:28px;color:#f5a623;letter-spacing:4px;}';
    document.head.appendChild(s);
  }

  function parseParams(params) {
    var l = 0, d = 0;
    if (typeof params === 'string') {
      var m = params.match(/[?&]l=(\d+)/); if (m) l = parseInt(m[1], 10);
      m = params.match(/[?&]d=(\d+)/); if (m) d = parseInt(m[1], 10);
    } else if (params && typeof params === 'object') {
      if (params.l != null) l = parseInt(params.l, 10) || 0;
      if (params.d != null) d = parseInt(params.d, 10) || 0;
    }
    return { l: l, d: d };
  }

  function r1(x) { return Math.round(x * 10) / 10; }

  function starsFor(kind, accuracy, netWpm) {
    if (accuracy >= 97 && netWpm >= (STAR_WPM[kind] || 20)) return 3;
    if (accuracy >= 90) return 2;
    if (accuracy >= 75) return 1;
    return 0;
  }

  /* Core drill runner. Shared by start() and startCustom().
   * opts: {text, label, sub, lessonIdx, drillIdx, kind, custom}
   * Returns stop(). */
  function run(el, opts) {
    ensureCss();
    el.innerHTML = '';
    var text = opts.text;

    var head = TM.el('div', 'tm-controls');
    var title = TM.el('h2', '', TM.escapeHtml(opts.label));
    title.style.margin = '0 0 4px 0';
    var sub = TM.el('div', 'tm-hint', TM.escapeHtml(opts.sub || ''));

    var stats = TM.el('div', 'tm-stats');
    var stWpm = TM.el('span', '', 'WPM <b>0</b>');
    var stAcc = TM.el('span', '', 'Accuracy <b>100%</b>');
    var stTime = TM.el('span', '', 'Time <b>0:00</b>');
    var stErr = TM.el('span', '', 'Errors <b>0</b>');
    stats.appendChild(stWpm); stats.appendChild(stAcc);
    stats.appendChild(stTime); stats.appendChild(stErr);

    // Target text: one span per char so we can color typed chars and show a
    // caret on the current one. Newlines render as a visible ⏎ marker that
    // the user "types" with Enter.
    var textEl = TM.el('div', 'tm-text');
    var spans = [];
    for (var i = 0; i < text.length; i++) {
      var ch = text[i];
      var sp;
      if (ch === '\n') {
        sp = TM.el('span', 'tm-nl', '&#8629;');
      } else {
        sp = TM.el('span', '', TM.escapeHtml(ch));
      }
      textEl.appendChild(sp);
      spans.push(sp);
    }

    var hint = TM.el('div', 'tm-hint', '');
    var kbWrap = TM.el('div', '');
    var kb = null;
    try {
      if (typeof TM.buildKeyboard === 'function') kb = TM.buildKeyboard(kbWrap);
    } catch (e) { kb = null; } // keyboard is optional decoration

    var controls = TM.el('div', 'tm-controls');
    var restartBtn = TM.el('button', 'tm-btn', 'Restart drill');
    restartBtn.type = 'button';
    var backBtn = TM.el('button', 'tm-btn', 'Back to course');
    backBtn.type = 'button';
    backBtn.addEventListener('click', function () { if (TM.nav) TM.nav('course'); });
    controls.appendChild(restartBtn);
    controls.appendChild(backBtn);

    var resultEl = TM.el('div', 'tm-result');
    resultEl.style.display = 'none';

    el.appendChild(head);
    head.appendChild(title);
    el.appendChild(sub);
    el.appendChild(stats);
    el.appendChild(textEl);
    el.appendChild(hint);
    el.appendChild(kbWrap);
    el.appendChild(controls);
    el.appendChild(resultEl);

    // ---- typing state ----
    var idx = 0, correct = 0, errors = 0;
    var errMap = {}; // expectedChar -> miss count, recorded at drill end
    var started = false, finished = false;
    var startTs = 0, timerId = null;

    function fingerFor(ch) {
      if (kb && typeof kb.fingerFor === 'function') {
        try { return kb.fingerFor(ch); } catch (e) { /* fall through */ }
      }
      if (typeof TM.fingerForChar === 'function') {
        try { return TM.fingerForChar(ch); } catch (e) { /* fall through */ }
      }
      return 'the shown';
    }

    function updateHint() {
      var ch = text[idx];
      if (ch == null || finished) { hint.textContent = ''; return; }
      var label = (ch === '\n') ? 'Enter' : (ch === ' ' ? 'Space' : ch);
      var msg = 'Press "' + label + '" with your ' + fingerFor(ch) + ' finger';
      if (ch >= 'A' && ch <= 'Z') msg += ' + Shift';
      hint.textContent = msg;
      if (kb && typeof kb.setHint === 'function') {
        try { kb.setHint(msg); } catch (e) {}
      }
    }

    function setCaret() {
      for (var i = 0; i < spans.length; i++) spans[i].classList.remove('tm-caret');
      if (idx < spans.length) {
        spans[idx].classList.add('tm-caret');
        try { spans[idx].scrollIntoView({ block: 'nearest' }); } catch (e) {}
      }
      if (kb && typeof kb.setNext === 'function' && idx < text.length) {
        try { kb.setNext(text[idx]); } catch (e) {}
      }
      updateHint();
    }

    function elapsedSec() {
      return started ? (Date.now() - startTs) / 1000 : 0;
    }

    function updateStats() {
      var ks = correct + errors;
      var mins = elapsedSec() / 60;
      var gross = mins > 0 ? (ks / 5) / mins : 0;
      var acc = ks > 0 ? (100 * correct) / ks : 100;
      stWpm.innerHTML = 'WPM <b>' + r1(gross) + '</b>';
      stAcc.innerHTML = 'Accuracy <b>' + r1(acc) + '%</b>';
      stTime.innerHTML = 'Time <b>' + TM.fmtTime(Math.floor(elapsedSec())) + '</b>';
      stErr.innerHTML = 'Errors <b>' + errors + '</b>';
    }

    function startTimer() {
      started = true;
      startTs = Date.now();
      timerId = setInterval(updateStats, 250); // cleared in stop()/finish()
    }

    function finish() {
      finished = true;
      if (timerId) { clearInterval(timerId); timerId = null; }
      document.removeEventListener('keydown', onKey, true);
      var dur = elapsedSec();
      var ks = correct + errors;
      var mins = dur / 60;
      var gross = mins > 0 ? (ks / 5) / mins : 0;
      var net = Math.max(0, gross - errors / (mins || 1e-9));
      var acc = ks > 0 ? (100 * correct) / ks : 100;
      gross = r1(gross); net = r1(net); acc = r1(acc);

      var stars = 0, starsHtml = '';
      if (!opts.custom) {
        stars = starsFor(opts.kind, acc, net);
        starsHtml = '<div class="tm-stars">' +
          '&#9733;'.repeat(stars) + '<span style="color:#ddd">' + '&#9733;'.repeat(3 - stars) + '</span></div>';
        try { TM.setStar(opts.lessonIdx, opts.drillIdx, stars); } catch (e) {}
      }

      try {
        TM.appendSession({
          view: opts.custom ? 'review' : 'practice',
          lesson: opts.custom ? -1 : opts.lessonIdx,
          drill: opts.custom ? -1 : opts.drillIdx,
          durationSec: Math.round(dur),
          grossWpm: gross, netWpm: net, accuracy: acc,
          errors: errors, keystrokes: ks
        });
      } catch (e) {}
      try { TM.recordKeyErrors(errMap); } catch (e) {}

      // Next-step navigation
      var nextHtml = '';
      if (!opts.custom) {
        var li = opts.lessonIdx, di = opts.drillIdx;
        var totalLessons = (window.TMData && window.TMData.lessons) ? window.TMData.lessons.length : 12;
        if (di < 4) nextHtml = '<button class="tm-btn primary" data-next="drill">Next drill &rarr;</button>';
        else if (li < totalLessons - 1) nextHtml = '<button class="tm-btn primary" data-next="lesson">Next lesson &rarr;</button>';
        else nextHtml = '<button class="tm-btn primary" data-next="course">Back to course</button>';
      }

      resultEl.innerHTML =
        '<h3>Drill complete!</h3>' + starsHtml +
        '<table>' +
        '<tr><td>Gross WPM</td><td><b>' + gross + '</b></td></tr>' +
        '<tr><td>Net WPM</td><td><b>' + net + '</b></td></tr>' +
        '<tr><td>Accuracy</td><td><b>' + acc + '%</b></td></tr>' +
        '<tr><td>Errors</td><td><b>' + errors + '</b></td></tr>' +
        '<tr><td>Keystrokes</td><td><b>' + ks + '</b></td></tr>' +
        '<tr><td>Time</td><td><b>' + TM.fmtTime(Math.round(dur)) + '</b></td></tr>' +
        '</table>' +
        '<div class="tm-controls">' +
        '<button class="tm-btn" data-next="retry">Retry</button>' +
        nextHtml +
        '</div>';
      resultEl.style.display = 'block';
      textEl.style.display = 'none';

      var btns = resultEl.querySelectorAll('button[data-next]');
      for (var b = 0; b < btns.length; b++) {
        btns[b].addEventListener('click', function (ev) {
          var act = ev.currentTarget.getAttribute('data-next');
          if (act === 'retry') { restart(); }
          else if (act === 'drill') { if (TM.nav) TM.nav('practice', '?l=' + opts.lessonIdx + '&d=' + (opts.drillIdx + 1)); }
          else if (act === 'lesson') { if (TM.nav) TM.nav('practice', '?l=' + (opts.lessonIdx + 1) + '&d=0'); }
          else if (act === 'course') { if (TM.nav) TM.nav('course'); }
        });
      }
      try { resultEl.scrollIntoView({ block: 'nearest' }); } catch (e) {}
    }

    function onKey(e) {
      if (finished) return;
      // Global keydown rule: never hijack typing inside form fields.
      var t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
      if (e.key === 'Tab') { e.preventDefault(); return; }
      if (e.key === 'Backspace') { e.preventDefault(); return; } // no backspace in TM
      if (e.key === ' ') e.preventDefault(); // stop page scroll
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      var pressed = e.key;
      // Ignore lone modifier/function keys (Shift, CapsLock, F1...) — not errors.
      if (pressed.length > 1 && pressed !== 'Enter') return;
      if (idx >= text.length) return;

      if (!started) startTimer();

      var expected = text[idx];
      var ok = (expected === '\n') ? (pressed === 'Enter') : (pressed === expected);
      var sp = spans[idx];
      if (ok) {
        correct++;
        sp.classList.add('tm-ok');
      } else {
        errors++;
        errMap[expected] = (errMap[expected] || 0) + 1;
        sp.classList.add('tm-bad');
      }
      if (kb && typeof kb.flash === 'function') {
        try { kb.flash(expected, ok); } catch (e2) {}
      }
      idx++;
      if (idx >= text.length) { setCaret(); updateStats(); finish(); return; }
      setCaret();
      updateStats();
    }

    function restart() {
      // New attempt -> fresh deterministic text for this (lesson, drill, attempt).
      stop();
      if (opts.custom) {
        TM.Engine.startCustom(el, opts.text, opts.label);
      } else {
        TM.Engine.start(el, { lessonIdx: opts.lessonIdx, drillIdx: opts.drillIdx });
      }
    }
    restartBtn.addEventListener('click', restart);

    function stop() {
      finished = true;
      if (timerId) { clearInterval(timerId); timerId = null; }
      document.removeEventListener('keydown', onKey, true);
    }

    document.addEventListener('keydown', onKey, true);
    setCaret();
    updateStats();
    return stop;
  }

  /* Public engine API. */
  var Engine = {
    start: function (el, opts) {
      opts = opts || {};
      var li = Math.max(0, opts.lessonIdx | 0);
      var di = Math.max(0, Math.min(4, opts.drillIdx | 0));
      var D = window.TMData;
      var lesson = D.lessons[li];
      var drill = lesson.drills[di];
      var attemptNo = D.newAttempt(); // bump BEFORE makeDrill so text matches the header
      var text = D.makeDrill(li, di);
      return run(el, {
        text: text,
        label: drill.title,
        sub: lesson.title + ' — ' + lesson.subtitle + '  ·  Attempt ' + attemptNo,
        lessonIdx: li, drillIdx: di, kind: drill.kind, custom: false
      });
    },
    startCustom: function (el, text, label) {
      return run(el, {
        text: String(text),
        label: label || 'Custom drill',
        sub: 'Custom practice',
        lessonIdx: -1, drillIdx: -1, kind: 'review', custom: true
      });
    }
  };

  TM.Engine = Engine;

  /* ---- 'practice' view registration ---- */
  var currentStop = null;
  TM.registerView('practice', {
    mount: function (el, params) {
      var p = parseParams(params);
      var D = window.TMData;
      var total = D.lessons.length;
      var l = Math.min(Math.max(p.l | 0, 0), total - 1);
      var d = Math.min(Math.max(p.d | 0, 0), 4);
      if (typeof TM.isLessonUnlocked === 'function' && !TM.isLessonUnlocked(l)) {
        el.innerHTML = '';
        var box = TM.el('div', 'tm-result');
        box.innerHTML = '<h3>Lesson locked</h3>' +
          '<p>Complete the previous lesson to unlock ' +
          TM.escapeHtml(D.lessons[l].title) + '.</p>' +
          '<div class="tm-controls"><button class="tm-btn" id="tm-back">Back to course</button></div>';
        el.appendChild(box);
        var back = box.querySelector('#tm-back');
        if (back) back.addEventListener('click', function () { if (TM.nav) TM.nav('course'); });
        return;
      }
      currentStop = Engine.start(el, { lessonIdx: l, drillIdx: d });
    },
    unmount: function () {
      if (currentStop) {
        try { currentStop(); } catch (e) {}
        currentStop = null;
      }
    }
  });
})();
