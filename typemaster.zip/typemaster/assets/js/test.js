/* TypingMaster 11 clone — Typing Test view.
 * Registers 'test' via window.TM (loaded before this file).
 * Vanilla JS, zero external requests, works from file://.
 */
(function () {
  'use strict';
  var TM = window.TM;
  if (!TM) return; // app.js must load first; bail safely otherwise

  // ------------------------------------------------------------------
  // Built-in practice paragraphs (~120-180 words each, original prose,
  // plain ASCII, everyday topics). One is picked at random per attempt.
  // ------------------------------------------------------------------
  var PARAGRAPHS = [
    // morning routine
    "The morning begins quietly, long before the rest of the house wakes up. " +
    "I slip out of bed and pad across the cool floor to the kitchen, where the " +
    "coffee maker is already warming up from its timer. While the coffee brews, " +
    "I open the blinds and let the early light spill across the table. The street " +
    "outside is still empty, and the birds are doing all the talking. I drink my " +
    "first cup slowly, standing at the window, planning the day ahead in loose " +
    "strokes rather than a strict list. After breakfast, I shower, dress, and pack " +
    "my bag with whatever the day demands. A quick glance at the clock tells me " +
    "there is still time, so I water the plants on the sill and lock the door " +
    "with the calm feeling of someone who is ready for whatever comes next.",

    // a park
    "The park on Saturday morning belongs to the early risers and the dogs. " +
    "Joggers circle the pond while ducks argue over crumbs near the footbridge. " +
    "An old man feeds pigeons from a bench he has clearly claimed as his own, " +
    "and two kids race paper boats along the stream that feeds the fountain. " +
    "The air smells of cut grass and fresh bread from the bakery on the corner. " +
    "I find a spot under the oldest oak and watch the clouds drag their shadows " +
    "across the lawn. A chess game draws a small crowd near the gate, where the " +
    "moves are debated as loudly as they are played. By noon the paths fill with " +
    "families and picnic baskets, and the quiet gives way to cheerful noise. " +
    "I leave with a book only half read and the good feeling that the city " +
    "still knows how to slow down.",

    // cooking
    "Cooking a proper meal starts with a clean counter and a sharp knife. I lay " +
    "out everything I need before turning on the stove, because hunting for a " +
    "spice while the onions burn is a mistake I have made too many times. The " +
    "garlic goes in first, just long enough to smell wonderful, then the chopped " +
    "tomatoes and a pinch of salt. While the sauce simmers, I boil the pasta and " +
    "taste it a minute early to catch it at the right bite. Fresh basil from the " +
    "windowsill pot goes on at the very end, never while it cooks. The kitchen " +
    "fills with steam and the sound of a spoon against the pot, which might be " +
    "the most comforting music in the world. We eat at the table, phones away, " +
    "and the plate is empty before the conversation is. Good food needs nothing " +
    "fancy, just patience and decent ingredients.",

    // travel
    "The train pulled out of the station just as the sun was coming up, and I " +
    "had a window seat facing the direction of travel. Fields gave way to small " +
    "towns, and small towns gave way to a coastline that glittered the whole " +
    "morning. I had packed light: one bag, a paperback, and a paper map that " +
    "refused to fold properly. The conductor stamped my ticket with a satisfying " +
    "thunk, and the dining car served coffee strong enough to stand a spoon in. " +
    "Somewhere past the third stop, an old woman shared her biscuits and told me " +
    "about the village where she grew up, pointing out landmarks I would never " +
    "have noticed. By the time we arrived, I felt like I had already seen the " +
    "place through two sets of eyes. Travel reminds you that the world is both " +
    "enormous and surprisingly friendly.",

    // technology
    "Technology sneaks into our lives through small conveniences that pile up " +
    "until they become essentials. A phone that once just made calls now holds " +
    "our maps, our music, our tickets, and our family photos. The internet, which " +
    "started as a curiosity for hobbyists, now carries entire businesses and " +
    "classrooms across continents. What amazes me most is not the speed of the " +
    "change but how quickly we adapt to it. Video calls with grandparents feel " +
    "normal, and we trust a small device to remember everything we cannot. Of " +
    "course there are tradeoffs: attention is harder to hold, and not everything " +
    "online deserves our trust. But used with care, these tools connect people " +
    "who would otherwise never meet and give ordinary folks a voice. The trick " +
    "is staying in charge of the tools instead of letting them run the day.",

    // books
    "There is a particular joy in finding a book that seems to have been waiting " +
    "for you. The cover catches your eye on a crowded shelf, and the first page " +
    "pulls you in before you have even left the shop. Reading is the cheapest " +
    "form of travel ever invented: one chair, one lamp, and suddenly you are in " +
    "another century or another world entirely. I keep a stack by the bed that " +
    "never quite shrinks, because every finished book reveals two more worth " +
    "reading. Some books I finish in a day, others I savor for weeks, and a few " +
    "special ones I reread just to spend time with familiar friends. The smell " +
    "of paper, the weight of a hardcover, the crease of a well-loved spine — " +
    "these small pleasures never get old. A good book does not just pass the " +
    "time; it quietly rearranges how you see it.",

    // weather
    "The weather turned overnight, and I woke to rain tapping insistently on the " +
    "windows. The forecast had promised sunshine, which only proved that the sky " +
    "makes its own plans. I watched the street turn glossy and the gutters run " +
    "like small rivers while I finished my toast. By midday the clouds thinned " +
    "and a pale sun broke through, turning every puddle into a mirror. People " +
    "emerged blinking, umbrellas still half open out of habit. The air smelled " +
    "clean and green, the way it only does after a good wash. Children splashed " +
    "through the last of the puddles on their way home from school, and the " +
    "birds resumed their arguments in the hedges. It is funny how much a change " +
    "in the weather can reset a mood. Tomorrow may be gray again, but today the " +
    "light feels like a gift.",

    // work
    "A good workday starts the night before, with a desk cleared and a short " +
    "list of what matters most. I tackle the hardest task first, before the " +
    "inbox has a chance to scatter my attention. Meetings are kept short and " +
    "standing when possible, because a chair is where decisions go to nap. " +
    "Around midday I take a real break: a walk outside, no screen, just fresh " +
    "air and whatever thoughts wander by. The afternoon is for the steady work, " +
    "the careful replies, and the small fixes that keep everything moving. I " +
    "have learned to write things down the moment they occur, since memory is a " +
    "poor filing cabinet. At the end of the day I close the laptop and leave " +
    "the list for tomorrow, trusting that rest is part of the job too. Progress " +
    "is rarely dramatic; it is the quiet sum of ordinary days done well.",

    // sports
    "The final match drew a crowd that filled every seat and spilled onto the " +
    "grass banks behind the goals. Both teams had fought through a long season " +
    "to get here, and the tension in the air was almost visible. The first half " +
    "was a stalemate, all missed chances and heroic saves, but nobody in the " +
    "stands sat down. Just after the break, a quick counterattack broke the " +
    "deadlock, and the roar could probably be heard three streets away. The " +
    "trailing team pressed hard and nearly equalized twice, the crossbar saving " +
    "the leaders once in the dying minutes. When the whistle finally blew, the " +
    "winners collapsed in a pile while the losers were applauded off the field. " +
    "That is the best part of sport: it asks everything of you, and even in " +
    "defeat it leaves you with a story worth telling.",

    // music
    "Learning an instrument is an exercise in patience disguised as fun. The " +
    "first weeks are mostly squeaks and sore fingers, and the neighbors learn " +
    "more about your struggle than they ever asked to. But then one evening the " +
    "chords start to land cleanly, and a simple song flows out almost by itself. " +
    "Music has a way of marking time: certain songs belong to certain summers, " +
    "and a single melody can carry you back a decade in three seconds. Playing " +
    "with others teaches listening in a way words never could; everyone must " +
    "breathe together or the whole thing falls apart. I practice most evenings, " +
    "not because I must, but because the hour with the guitar is the calmest " +
    "part of my day. You do not need talent to begin, only the willingness to " +
    "sound terrible for a while. The music is worth the wait."
  ];

  var DURATIONS = [1, 2, 5, 10];
  var DEFAULT_MINS = 2;

  function bestKey(mins) { return 'test_' + mins; }

  // Grade rule: [minNetWpm, minAcc, stars]
  function stars(netWpm, acc) {
    if (netWpm >= 40 && acc >= 97) return 3;
    if (netWpm >= 25 && acc >= 90) return 2;
    if (netWpm >= 12 && acc >= 80) return 1;
    return 0;
  }

  // Module-level handle so unmount can clean up even if TM calls
  // mount/unmount without preserving `this`.
  var activeCleanup = null;

  TM.registerView('test', {
    mount: function (el, params) {
      el.innerHTML = '';
      var state = {
        screen: 'start',
        mins: DEFAULT_MINS,
        paragraph: '',
        chars: [],        // span elements, one per char
        idx: 0,           // next char to type
        keystrokes: 0,
        correct: 0,
        errors: 0,
        errMap: {},       // expected char -> count
        startTs: 0,       // first keystroke timestamp
        timerId: 0,
        remaining: 0,
        done: false,
        boundKeydown: null
      };

      // ---------------- start screen ----------------
      function renderStart() {
        state.screen = 'start';
        el.innerHTML = '';
        var wrap = TM.el('div', 'tm-test tm-start');
        wrap.innerHTML =
          '<h1>Typing Test</h1>' +
          '<p class="tm-lead">Type as much of the passage as you can before the ' +
          'timer runs out. There is <strong>no backspace</strong> in this test: ' +
          'every wrong key counts as an error, so stay accurate.</p>' +
          '<div class="tm-durations"><span>Duration:</span></div>' +
          '<div class="tm-best" aria-live="polite"></div>' +
          '<div class="tm-actions">' +
            '<button type="button" class="tm-btn tm-primary" data-act="start">Start test</button>' +
          '</div>' +
          '<p class="tm-hint">How it works: the clock starts on your first keystroke. ' +
          'The test ends when time runs out or you finish the passage.</p>';
        var durRow = wrap.querySelector('.tm-durations');
        DURATIONS.forEach(function (m) {
          var b = TM.el('button', 'tm-btn tm-dur' + (m === state.mins ? ' tm-active' : ''),
            m + (m === 1 ? ' min' : ' min'));
          b.type = 'button';
          b.setAttribute('data-mins', String(m));
          durRow.appendChild(b);
        });
        el.appendChild(wrap);
        updateBestLine();
        wrap.addEventListener('click', onStartClick);
      }

      function updateBestLine() {
        var box = el.querySelector('.tm-best');
        if (!box) return;
        var best = TM.getBest(bestKey(state.mins), null);
        if (best && typeof best.netWpm === 'number') {
          var d = best.ts ? new Date(best.ts) : null;
          box.innerHTML = 'Personal best (' + state.mins + ' min): <strong>' +
            TM.escapeHtml(String(Math.round(best.netWpm))) + ' net WPM</strong>, ' +
            TM.escapeHtml(String(Math.round(best.accuracy))) + '% accuracy' +
            (d ? ' &middot; ' + TM.escapeHtml(d.toLocaleDateString()) : '');
        } else {
          box.textContent = 'No personal best yet for ' + state.mins + ' min. Set one!';
        }
      }

      function onStartClick(e) {
        var t = e.target;
        if (!t || typeof t.getAttribute !== "function") return;
        var mins = t.getAttribute('data-mins');
        if (mins) {
          state.mins = parseInt(mins, 10) || DEFAULT_MINS;
          var btns = el.querySelectorAll('.tm-dur');
          for (var i = 0; i < btns.length; i++) {
            btns[i].classList.toggle('tm-active',
              btns[i].getAttribute('data-mins') === String(state.mins));
          }
          updateBestLine();
          return;
        }
        if (t.getAttribute('data-act') === 'start') startTest();
      }

      // ---------------- test screen ----------------
      function startTest() {
        state.screen = 'run';
        state.paragraph = PARAGRAPHS[Math.floor(Math.random() * PARAGRAPHS.length)];
        state.idx = 0;
        state.keystrokes = 0;
        state.correct = 0;
        state.errors = 0;
        state.errMap = {};
        state.startTs = 0;
        state.remaining = state.mins * 60;
        state.done = false;

        el.innerHTML = '';
        var wrap = TM.el('div', 'tm-test tm-run');
        wrap.innerHTML =
          '<div class="tm-statsbar">' +
            '<div class="tm-stat"><span class="tm-stat-label">Time</span><span class="tm-stat-val" data-s="time"></span></div>' +
            '<div class="tm-stat"><span class="tm-stat-label">WPM</span><span class="tm-stat-val" data-s="wpm">0</span></div>' +
            '<div class="tm-stat"><span class="tm-stat-label">Accuracy</span><span class="tm-stat-val" data-s="acc">100%</span></div>' +
            '<div class="tm-stat"><span class="tm-stat-label">Typed</span><span class="tm-stat-val" data-s="typed">0</span></div>' +
          '</div>' +
          '<div class="tm-progress"><div class="tm-progress-fill"></div></div>' +
          '<div class="tm-passage" tabindex="0" role="textbox" aria-label="Typing passage"></div>' +
          '<p class="tm-hint">Start typing — the timer begins on your first keystroke. No backspace.</p>';
        var passage = wrap.querySelector('.tm-passage');
        state.chars = [];
        for (var i = 0; i < state.paragraph.length; i++) {
          var sp = TM.el('span', 'tm-ch');
          sp.textContent = state.paragraph[i];
          passage.appendChild(sp);
          state.chars.push(sp);
        }
        if (state.chars.length) state.chars[0].classList.add('tm-caret');
        el.appendChild(wrap);
        setStats();

        // Focus the passage so keyboard users land in the right place.
        try { passage.focus({ preventScroll: true }); } catch (err) { passage.focus(); }

        state.boundKeydown = onKey;
        document.addEventListener('keydown', state.boundKeydown);
      }

      function setStats() {
        var s = el.querySelectorAll('[data-s]');
        var elapsed = state.startTs ? (Date.now() - state.startTs) / 1000 : 0;
        var elapsedMin = Math.max(elapsed / 60, 1 / 600); // avoid div-by-zero on first paint
        var gross = (state.keystrokes / 5) / elapsedMin;
        var acc = state.keystrokes ? (state.correct / state.keystrokes) * 100 : 100;
        var map = { time: TM.fmtTime(Math.ceil(state.remaining)), wpm: String(Math.round(gross)),
                    acc: Math.round(acc) + '%', typed: String(state.keystrokes) };
        for (var i = 0; i < s.length; i++) {
          var k = s[i].getAttribute('data-s');
          if (map[k] !== undefined) s[i].textContent = map[k];
        }
        var fill = el.querySelector('.tm-progress-fill');
        if (fill) fill.style.width = Math.round((state.idx / state.paragraph.length) * 100) + '%';
      }

      function tick() {
        state.remaining -= 1;
        if (state.remaining <= 0) { finish(); return; }
        setStats();
      }

      function onKey(e) {
        if (state.screen !== 'run' || state.done) return;
        var tag = e.target && e.target.tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
        if (e.target && e.target.isContentEditable) return;

        // No backspace in this test: ignore it entirely.
        if (e.key === 'Backspace') { e.preventDefault(); return; }
        if (e.key === 'Tab') { e.preventDefault(); return; }
        // Ignore modifiers / navigation keys; only printable chars + Space.
        if (e.key.length !== 1 && e.key !== 'Enter') return;
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        e.preventDefault();

        // First keystroke starts the clock.
        if (!state.startTs) {
          state.startTs = Date.now();
          state.timerId = window.setInterval(tick, 1000);
        }

        var expected = state.paragraph[state.idx];
        // Treat Enter as a space-like separator? Paragraphs have no newlines,
        // so stray Enter presses simply count against the current char.
        var typed = e.key === 'Enter' ? '\n' : e.key;
        state.keystrokes++;

        var span = state.chars[state.idx];
        span.classList.remove('tm-caret');
        if (typed === expected) {
          span.classList.add('tm-ok');
          state.correct++;
        } else {
          span.classList.add('tm-bad');
          state.errors++;
          state.errMap[expected] = (state.errMap[expected] || 0) + 1;
        }
        state.idx++;
        if (state.idx >= state.paragraph.length) { finish(); return; }
        state.chars[state.idx].classList.add('tm-caret');
        setStats();
      }

      function finish() {
        if (state.done) return;
        state.done = true;
        if (state.timerId) { window.clearInterval(state.timerId); state.timerId = 0; }
        if (state.boundKeydown) {
          document.removeEventListener('keydown', state.boundKeydown);
          state.boundKeydown = null;
        }

        var elapsedSec = state.startTs ? Math.max((Date.now() - state.startTs) / 1000, 1) : state.mins * 60;
        // If finished early, pad remaining time as done: duration used is elapsed.
        var elapsedMin = elapsedSec / 60;
        var grossWpm = (state.keystrokes / 5) / elapsedMin;
        var netWpm = Math.max(0, grossWpm - (state.errors / elapsedMin));
        var accuracy = state.keystrokes ? (state.correct / state.keystrokes) * 100 : 0;

        var session = {
          view: 'test',
          lesson: -1,
          drill: state.mins,
          durationSec: state.mins * 60,
          grossWpm: Math.round(grossWpm * 10) / 10,
          netWpm: Math.round(netWpm * 10) / 10,
          accuracy: Math.round(accuracy * 10) / 10,
          errors: state.errors,
          keystrokes: state.keystrokes
        };
        TM.appendSession(session);
        TM.recordKeyErrors(state.errMap);

        var key = bestKey(state.mins);
        var prev = TM.getBest(key, null);
        var isNew = !prev || session.netWpm > prev.netWpm;
        if (isNew) TM.setBest(key, { netWpm: session.netWpm, accuracy: session.accuracy, ts: Date.now() });

        renderResults(session, prev, isNew);
      }

      // ---------------- results screen ----------------
      function renderResults(session, prev, isNew) {
        state.screen = 'results';
        el.innerHTML = '';
        var wrap = TM.el('div', 'tm-test tm-results');
        var n = stars(session.netWpm, session.accuracy);
        var starLine = n > 0 ? '★'.repeat(n) + '☆'.repeat(3 - n) : '☆☆☆';
        var bestHtml;
        if (isNew) {
          bestHtml = '<p class="tm-newbest">🏆 New personal best!</p>' +
            (prev ? '<p class="tm-prevbest">Previous: ' + Math.round(prev.netWpm) +
              ' net WPM, ' + Math.round(prev.accuracy) + '% accuracy</p>' : '');
        } else if (prev) {
          bestHtml = '<p>Personal best: <strong>' + Math.round(prev.netWpm) +
            ' net WPM</strong>, ' + Math.round(prev.accuracy) + '% accuracy</p>';
        } else {
          bestHtml = '<p>No previous best recorded.</p>';
        }
        wrap.innerHTML =
          '<div class="tm-cert">' +
            '<h1>Test complete</h1>' +
            '<p class="tm-lead">' + state.mins + '-minute typing test</p>' +
            '<div class="tm-starline" aria-label="' + n + ' out of 3 stars">' + starLine + '</div>' +
            '<div class="tm-grid">' +
              gridRow('Gross WPM', session.grossWpm) +
              gridRow('Net WPM', session.netWpm) +
              gridRow('Accuracy', session.accuracy + '%') +
              gridRow('Keystrokes', session.keystrokes) +
              gridRow('Correct chars', state.correct) +
              gridRow('Wrong chars', session.errors) +
              gridRow('Time', TM.fmtTime(state.mins * 60)) +
              gridRow('Characters', state.paragraph.length) +
            '</div>' +
            '<div class="tm-bestbox">' + bestHtml + '</div>' +
            '<div class="tm-actions">' +
              '<button type="button" class="tm-btn tm-primary" data-act="again">Try again</button>' +
              '<button type="button" class="tm-btn" data-act="duration">Change duration</button>' +
              '<button type="button" class="tm-btn" data-act="course">Back to course</button>' +
            '</div>' +
          '</div>';
        el.appendChild(wrap);
        wrap.addEventListener('click', function (e) {
          var t = e.target;
          if (!t || typeof t.getAttribute !== "function") return;
          var act = t.getAttribute('data-act');
          if (act === 'again') startTest();
          else if (act === 'duration') renderStart();
          else if (act === 'course') { if (TM.nav) TM.nav('course'); else window.location.hash = '#/course'; }
        });
      }

      function gridRow(label, value) {
        return '<div class="tm-cell"><span class="tm-cell-label">' +
          TM.escapeHtml(label) + '</span><span class="tm-cell-val">' +
          TM.escapeHtml(String(value)) + '</span></div>';
      }

      renderStart();

      // ---------------- lifecycle ----------------
      activeCleanup = function () {
        if (state.timerId) { window.clearInterval(state.timerId); state.timerId = 0; }
        if (state.boundKeydown) {
          document.removeEventListener('keydown', state.boundKeydown);
          state.boundKeydown = null;
        }
        el.innerHTML = '';
      };
    },

    unmount: function () {
      if (activeCleanup) { activeCleanup(); activeCleanup = null; }
    }
  });

})();
