/* TypeMaster 11 — app.js
   Defines window.TM (the shared contract all modules depend on),
   the hash router, the course dashboard view, and the on-screen
   keyboard component. 100% vanilla JS, zero external requests,
   works from file://. */

(function () {
  'use strict';

  var TM = {};
  window.TM = TM;

  /* ================= Storage contract ================= */

  TM.PREFIX = 'tm11.';

  TM.save = function (name, obj) {
    try { localStorage.setItem(TM.PREFIX + name, JSON.stringify(obj)); } catch (e) {}
  };

  TM.load = function (name, fallback) {
    try {
      var v = localStorage.getItem(TM.PREFIX + name);
      return v == null ? fallback : JSON.parse(v);
    } catch (e) { return fallback; }
  };

  TM.appendSession = function (s) {
    var a = TM.load('sessions', []);
    s.ts = Date.now();
    a.push(s);
    if (a.length > 500) a = a.slice(-500);
    TM.save('sessions', a);
  };

  TM.recordKeyErrors = function (obj) {
    var m = TM.load('keyErrors', {});
    for (var k in obj) m[k] = (m[k] || 0) + obj[k];
    TM.save('keyErrors', m);
  };

  /* ---- drill stars: key 'l{lesson}d{drill}' -> 0..3, keep max ---- */
  TM.getStars = function () { return TM.load('stars', {}); };

  TM.setStar = function (li, di, stars) {
    var key = 'l' + li + 'd' + di;
    var m = TM.getStars();
    if ((m[key] || 0) < stars) { m[key] = stars; TM.save('stars', m); }
  };

  /* Lesson i is unlocked if it is the first, or any drill of lesson i-1 has a star. */
  TM.isLessonUnlocked = function (i) {
    return i === 0 || Object.keys(TM.getStars()).some(function (k) {
      return k.indexOf('l' + (i - 1) + 'd') === 0;
    });
  };

  /* ---- personal bests ---- */
  TM.getBest = function (key, fb) {
    var b = TM.load('bests', {});
    return (b[key] !== undefined) ? b[key] : fb;
  };

  TM.setBest = function (key, val) {
    var b = TM.load('bests', {});
    b[key] = val;
    TM.save('bests', b);
  };

  /* ================= Small helpers ================= */

  TM.el = function (tag, cls, html) {
    var el = document.createElement(tag);
    if (cls) el.className = cls;
    if (html != null) el.innerHTML = html;
    return el;
  };

  /* seconds -> 'm:ss' */
  TM.fmtTime = function (sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    var m = Math.floor(sec / 60), s = sec % 60;
    return m + ':' + (s < 10 ? '0' : '') + s;
  };

  TM.escapeHtml = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };

  /* Parse a '?l=0&d=1' style query string into an object. Extra helper. */
  TM.parseParams = function (qs) {
    var o = {};
    if (!qs) return o;
    qs.replace(/^\?/, '').split('&').forEach(function (p) {
      var kv = p.split('=');
      if (kv[0]) o[decodeURIComponent(kv[0])] = decodeURIComponent(kv[1] || '');
    });
    return o;
  };

  /* Brief floating hint, used for locked lessons etc. */
  TM.toast = function (msg) {
    var t = document.getElementById('toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'toast';
      t.className = 'toast';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._h);
    t._h = setTimeout(function () { t.classList.remove('show'); }, 1700);
  };

  /* ================= View registry + navigation ================= */

  TM.views = {};

  TM.registerView = function (name, handlers) {
    TM.views[name] = handlers || {};
  };

  TM.nav = function (view, params) {
    location.hash = '#/' + view + (params || '');
  };

  /* ================= Router ================= */

  var VIEWS = ['course', 'practice', 'test', 'games', 'stats', 'review'];
  var current = null;

  function parseHash() {
    var h = location.hash || '';
    var m = /^#\/([a-z]+)(.*)$/.exec(h);
    if (!m) return { view: 'course', params: '' };
    return { view: m[1], params: m[2] || '' };
  }

  function refreshNavStars() {
    var el = document.getElementById('nav-course-stars');
    if (!el) return;
    var stars = TM.getStars(), total = 0;
    for (var k in stars) total += stars[k];
    el.textContent = total > 0 ? '★ ' + total : '';
  }

  function route() {
    var r = parseHash();
    var view = VIEWS.indexOf(r.view) >= 0 ? r.view : 'course';

    /* unmount previous view (guarded — never crash) */
    if (current && TM.views[current] && typeof TM.views[current].unmount === 'function') {
      try { TM.views[current].unmount(); } catch (e) {}
    }
    current = view;

    /* hide all sections, show the target */
    var sections = document.querySelectorAll('#main .view');
    for (var i = 0; i < sections.length; i++) sections[i].classList.remove('active');
    var target = document.getElementById('view-' + view);
    if (target) target.classList.add('active');

    /* nav highlight ('practice' has no nav item -> highlight course) */
    var navFor = (view === 'practice') ? 'course' : view;
    var items = document.querySelectorAll('#sidenav .nav-item');
    for (var j = 0; j < items.length; j++) {
      items[j].classList.toggle('active', items[j].getAttribute('data-view') === navFor);
    }
    refreshNavStars();

    /* mount the view, or a graceful placeholder if its module
       hasn't registered yet / failed to load */
    if (target) {
      var h = TM.views[view];
      if (h && typeof h.mount === 'function') {
        try { h.mount(target, r.params); }
        catch (e) {
          target.innerHTML = '<div class="placeholder">Something went wrong loading this view.</div>';
        }
      } else {
        target.innerHTML = '<div class="placeholder">Loading&hellip;</div>';
      }
    }
  }

  window.addEventListener('hashchange', route);

  /* ================= Course dashboard view ================= */

  function starsText(n) {
    n = Math.max(0, Math.min(3, n | 0));
    var s = '';
    for (var i = 0; i < 3; i++) s += i < n ? '★' : '☆';
    return s;
  }

  /* Make bests keys human-readable: 'testBestWpm' -> 'Test Best Wpm'. */
  function prettyBestKey(k) {
    return String(k)
      .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
      .replace(/[_-]+/g, ' ')
      .replace(/\b\w/g, function (c) { return c.toUpperCase(); });
  }

  function mountCourse(el) {
    el.innerHTML = '';
    var lessons = (window.TMData && window.TMData.lessons) || null;
    if (!lessons || !lessons.length) {
      el.appendChild(TM.el('div', 'placeholder', 'Course data loading&hellip;'));
      return;
    }

    var stars = TM.getStars();
    var totalStars = 0, drillsStarred = 0;
    for (var sk in stars) { totalStars += stars[sk]; drillsStarred++; }
    var unlockedCount = 0;
    for (var li = 0; li < lessons.length; li++) if (TM.isLessonUnlocked(li)) unlockedCount++;
    var sessions = TM.load('sessions', []);

    /* welcome card */
    var welcome = TM.el('div', 'card welcome');
    welcome.innerHTML =
      '<h2>Welcome to TypeMaster 11</h2>' +
      '<p>Learn touch typing step by step: 12 lessons, 5 drills each. ' +
      'Earn up to 3 stars per drill &mdash; finishing any drill unlocks the next lesson.</p>' +
      '<div class="stat-line">' +
        '<div class="stat"><b>' + unlockedCount + '/' + lessons.length + '</b>lessons unlocked</div>' +
        '<div class="stat"><b>' + totalStars + '</b>stars earned</div>' +
        '<div class="stat"><b>' + sessions.length + '</b>sessions</div>' +
      '</div>';
    el.appendChild(welcome);

    /* personal bests + quick start row */
    var row = TM.el('div', 'card-row');
    var bestsCard = TM.el('div', 'card');
    bestsCard.innerHTML = '<h3>Personal Bests</h3>';
    var bests = TM.load('bests', {});
    var keys = Object.keys(bests);
    if (!keys.length) {
      bestsCard.appendChild(TM.el('p', 'empty-note', 'No personal bests yet &mdash; complete a test or drill.'));
    } else {
      var ul = TM.el('ul', 'bests-list');
      keys.slice(0, 8).forEach(function (k) {
        var li = TM.el('li', '',
          '<span>' + TM.escapeHtml(prettyBestKey(k)) + '</span>' +
          '<span class="best-val">' + TM.escapeHtml(bests[k]) + '</span>');
        ul.appendChild(li);
      });
      bestsCard.appendChild(ul);
    }
    var tipCard = TM.el('div', 'card');
    tipCard.innerHTML =
      '<h3>How it works</h3>' +
      '<p>Place your fingers on the home row <b>asdf</b> &mdash; <b>jkl;</b>. ' +
      'Each key is colour-coded by finger on the on-screen keyboard.</p>' +
      '<button class="btn btn-primary" id="btn-continue">Continue course</button>';
    row.appendChild(bestsCard);
    row.appendChild(tipCard);
    el.appendChild(row);

    /* lesson grid */
    var gridHead = TM.el('h2', '', 'Typing Course');
    gridHead.style.margin = '6px 0 14px';
    el.appendChild(gridHead);
    var grid = TM.el('div', 'lesson-grid');
    lessons.forEach(function (L, i) {
      var unlocked = TM.isLessonUnlocked(i);
      var card = TM.el('div', 'lesson-card' + (unlocked ? '' : ' locked'));
      card.setAttribute('data-lesson', i);
      card.innerHTML =
        '<div class="lesson-num">Lesson ' + (i + 1) + (unlocked ? '' : ' &mdash; locked') + '</div>' +
        '<h3>' + TM.escapeHtml(L.title || ('Lesson ' + (i + 1))) + '</h3>' +
        '<div class="lesson-sub">' + TM.escapeHtml(L.subtitle || '') + '</div>' +
        '<div class="lesson-keys">' + TM.escapeHtml(L.keys || '') + '</div>';
      var drow = TM.el('div', 'drill-row');
      for (var d = 0; d < 5; d++) {
        var drill = (L.drills && L.drills[d]) || {};
        var name = drill.name || drill.title || ('Drill ' + (d + 1));
        var chip = TM.el('button', 'drill-chip',
          '<span class="chip-name">' + TM.escapeHtml(name) + '</span>' +
          '<span class="chip-stars">' + starsText(stars['l' + i + 'd' + d] || 0) + '</span>');
        chip.type = 'button';
        chip.setAttribute('data-l', i);
        chip.setAttribute('data-d', d);
        if (!unlocked) chip.setAttribute('disabled', 'disabled');
        drow.appendChild(chip);
      }
      card.appendChild(drow);
      grid.appendChild(card);
    });
    el.appendChild(grid);

    /* clicks: unlocked drill -> practice; locked card -> hint */
    grid.addEventListener('click', function (ev) {
      var chip = ev.target.closest ? ev.target.closest('.drill-chip') : null;
      var card = ev.target.closest ? ev.target.closest('.lesson-card') : null;
      if (!card) return;
      var i = parseInt(card.getAttribute('data-lesson'), 10);
      if (!TM.isLessonUnlocked(i)) {
        TM.toast('Complete the previous lesson first');
        return;
      }
      if (chip && !chip.disabled) {
        var d = parseInt(chip.getAttribute('data-d'), 10);
        TM.nav('practice', '?l=' + i + '&d=' + d);
      }
    });

    /* continue -> first drill without stars */
    var btn = document.getElementById('btn-continue');
    if (btn) btn.addEventListener('click', function () {
      outer:
      for (var i = 0; i < lessons.length; i++) {
        if (!TM.isLessonUnlocked(i)) break;
        for (var d = 0; d < 5; d++) {
          if (!(stars['l' + i + 'd' + d] > 0)) { TM.nav('practice', '?l=' + i + '&d=' + d); break outer; }
        }
      }
    });
  }

  TM.registerView('course', {
    mount: mountCourse,
    unmount: function () { /* nothing to tear down */ }
  });

  /* ================= Finger map + keyboard component ================= */

  /* Standard touch-typing finger assignment. */
  var FINGER_TABLE = [
    ['Left pinky',   ['`', '1', 'q', 'a', 'z', 'Tab']],
    ['Left ring',    ['2', 'w', 's', 'x']],
    ['Left middle',  ['3', 'e', 'd', 'c']],
    ['Left index',   ['4', '5', 'r', 't', 'f', 'g', 'v', 'b']],
    ['Right index',  ['6', '7', 'y', 'u', 'h', 'j', 'n', 'm']],
    ['Right middle', ['8', 'i', 'k', ',']],
    ['Right ring',   ['9', 'o', 'l', '.']],
    ['Right pinky',  ['0', '-', '=', 'p', '[', ']', '\\', ';', "'", '/']],
    ['Thumb',        [' ']]
  ];

  var FINGER_OF = {};
  FINGER_TABLE.forEach(function (pair) {
    pair[1].forEach(function (c) { FINGER_OF[c] = pair[0]; });
  });
  /* uppercase letters use the same finger as their lowercase form */
  'abcdefghijklmnopqrstuvwxyz'.split('').forEach(function (c) {
    if (FINGER_OF[c]) FINGER_OF[c.toUpperCase()] = FINGER_OF[c];
  });

  /* Lowercase lookup; Shift is shown separately by the engine. */
  TM.fingerForChar = function (ch) {
    if (ch == null) return '';
    var c = String(ch);
    if (c === ' ') return 'Thumb';
    return FINGER_OF[c] || FINGER_OF[c.toLowerCase()] || '';
  };

  function fingerClass(finger) {
    if (!finger) return '';
    if (finger.indexOf('pinky') >= 0) return 'f-pinky';
    if (finger.indexOf('ring') >= 0) return 'f-ring';
    if (finger.indexOf('middle') >= 0) return 'f-middle';
    if (finger.indexOf('index') >= 0) return 'f-index';
    if (finger === 'Thumb') return 'f-thumb';
    return '';
  }

  var KB_ROWS = [
    ['`', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '='],
    ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\\'],
    ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', "'"],
    ['z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/'],
    [' ']
  ];

  /* Renders a QWERTY keyboard with finger-zone colours.
     Returns { el, setNext(char), flash(char, ok), fingerFor(char), setHint(text) }. */
  TM.buildKeyboard = function (container) {
    var wrap = TM.el('div', 'kb');
    var keyEls = {}; /* lookup char -> element */

    KB_ROWS.forEach(function (row) {
      var r = TM.el('div', 'kb-row');
      row.forEach(function (ch) {
        var k = document.createElement('button');
        k.type = 'button';
        k.tabIndex = -1; /* keyboard is display-only; real input comes from the physical keyboard */
        k.className = 'key ' + fingerClass(TM.fingerForChar(ch));
        k.textContent = (ch === ' ') ? 'Space' : ch;
        if (ch === ' ') k.classList.add('space');
        k.setAttribute('data-key', ch);
        keyEls[ch] = k;
        r.appendChild(k);
      });
      wrap.appendChild(r);
    });

    var hint = TM.el('div', 'kb-hint', '');
    wrap.appendChild(hint);
    container.appendChild(wrap);

    var currentNext = null;

    function findEl(ch) {
      if (ch === ' ') return keyEls[' '] || null;
      var c = String(ch);
      return keyEls[c] || keyEls[c.toLowerCase()] || null;
    }

    return {
      el: wrap,
      /* highlight the expected key, clearing the previous highlight */
      setNext: function (ch) {
        if (currentNext) currentNext.classList.remove('next');
        currentNext = findEl(ch);
        if (currentNext) currentNext.classList.add('next');
        var f = TM.fingerForChar(ch);
        hint.textContent = f ? 'Press with your ' + f + ' finger' : '';
      },
      /* brief green/red flash on a key press */
      flash: function (ch, ok) {
        var kEl = findEl(ch);
        if (!kEl) return;
        var cls = ok ? 'flash-ok' : 'flash-bad';
        kEl.classList.remove('flash-ok', 'flash-bad');
        void kEl.offsetWidth; /* restart the CSS animation */
        kEl.classList.add(cls);
        setTimeout(function () { kEl.classList.remove(cls); }, 240);
      },
      fingerFor: function (ch) { return TM.fingerForChar(ch); },
      setHint: function (text) { hint.textContent = text || ''; }
    };
  };

  /* ================= Boot ================= */

  /* nav items clickable (also keyboard-accessible via Enter) */
  function bindNav() {
    var items = document.querySelectorAll('#sidenav .nav-item');
    for (var i = 0; i < items.length; i++) {
      (function (item) {
        var go = function () { TM.nav(item.getAttribute('data-view')); };
        item.addEventListener('click', go);
        item.addEventListener('keydown', function (ev) {
          if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); go(); }
        });
      })(items[i]);
    }
  }

  function boot() {
    bindNav();
    var d = document.getElementById('status-date');
    if (d) d.textContent = new Date().toLocaleDateString('en-GB', {
      weekday: 'short', day: '2-digit', month: 'short', year: 'numeric'
    });
    route();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

})();
