/* TypingMaster 11 — games.js
 * Workstream 4: games hub + three canvas typing games (Bubbles, WordTris, Clouds).
 * Vanilla JS, zero external requests, works from file://.
 * Registers the 'games' view via window.TM (loaded before this file by app.js).
 * All rendering is canvas 2D; input comes from the physical keyboard.
 */
(function () {
'use strict';

/* ------------------------------------------------------------------ */
/* 1. Shared contract guards (window.TM is guaranteed; guard cheaply)  */
/* ------------------------------------------------------------------ */
var TM = window.TM || null;

function el(tag, cls, html) {
  if (TM && TM.el) return TM.el(tag, cls, html);
  var d = document.createElement(tag || 'div');
  if (cls) d.className = cls;
  if (html != null) d.innerHTML = html;
  return d;
}
function esc(s) {
  if (TM && TM.escapeHtml) return TM.escapeHtml(s);
  return String(s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
function getBest(key, fb) {
  if (TM && TM.getBest) return TM.getBest(key, fb);
  try {
    var b = JSON.parse(localStorage.getItem('tm11.bests') || '{}');
    return (b && b[key] != null) ? b[key] : fb;
  } catch (e) { return fb; }
}
function setBest(key, val) {
  if (TM && TM.setBest) { TM.setBest(key, val); return; }
  try {
    var b = JSON.parse(localStorage.getItem('tm11.bests') || '{}');
    b[key] = val;
    localStorage.setItem('tm11.bests', JSON.stringify(b));
  } catch (e) { /* storage unavailable; ignore */ }
}

/* ------------------------------------------------------------------ */
/* 2. Small shared utilities                                            */
/* ------------------------------------------------------------------ */
// True when the key event came from an editable field — games ignore it.
function isEditableTarget(e) {
  var t = e.target;
  if (!t) return false;
  var tag = (t.tagName || '').toLowerCase();
  return tag === 'input' || tag === 'textarea' || tag === 'select' || !!t.isContentEditable;
}
function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
function rand(a, b) { return a + Math.random() * (b - a); }
function pick(arr) { return arr[(Math.random() * arr.length) | 0]; }

function roundRect(ctx, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

// requestAnimationFrame loop with clamped delta time (seconds).
// update(dt) runs game logic, draw() renders. stop() halts cleanly.
function makeLoop(update, draw) {
  var raf = 0, last = 0, running = false;
  function frame(ts) {
    if (!running) return;
    if (!last) last = ts;
    var dt = Math.min(0.05, (ts - last) / 1000); // clamp: tab-switch spikes
    last = ts;
    update(dt);
    draw();
    raf = requestAnimationFrame(frame);
  }
  return {
    start: function () {
      if (running) return;
      running = true; last = 0;
      raf = requestAnimationFrame(frame);
    },
    stop: function () { running = false; cancelAnimationFrame(raf); }
  };
}

/* ------------------------------------------------------------------ */
/* 3. Scoped styles (injected once; keeps this file self-contained)     */
/* ------------------------------------------------------------------ */
var CSS =
  '.tmg-hub{max-width:980px;margin:0 auto;padding:28px 18px;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#1a2233}' +
  '.tmg-hub h2{margin:0 0 6px;font-size:28px}' +
  '.tmg-hub p.sub{margin:0 0 8px;color:#5b6478}' +
  '.tmg-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:16px;margin-top:18px}' +
  '.tmg-card{background:#fff;border:1px solid #e3e7f0;border-radius:14px;padding:20px;box-shadow:0 2px 10px rgba(20,30,60,.06);display:flex;flex-direction:column;gap:10px}' +
  '.tmg-card .icon{font-size:34px;line-height:1}' +
  '.tmg-card h3{margin:0;font-size:20px}' +
  '.tmg-card p{margin:0;color:#5b6478;font-size:14px;flex:1}' +
  '.tmg-card .best{font-size:13px;color:#8a93a8;font-weight:600}' +
  '.tmg-screen{max-width:780px;margin:0 auto;padding:18px 14px 30px;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#1a2233;text-align:center}' +
  '.tmg-back{display:inline-block;margin:0 0 12px;color:#2f6fed;background:none;border:none;font-size:15px;cursor:pointer;padding:6px 4px}' +
  '.tmg-back:hover{text-decoration:underline}' +
  '.tmg-title{margin:0 0 10px;font-size:24px}' +
  '.tmg-wrap{position:relative;display:inline-block;max-width:100%}' +
  'canvas.tmg-canvas{display:block;border-radius:12px;max-width:100%;height:auto;box-shadow:0 4px 24px rgba(10,20,50,.25)}' +
  '.tmg-ov{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(6,10,24,.8);border-radius:12px;color:#fff;padding:24px;box-sizing:border-box}' +
  '.tmg-ov .box{max-width:420px}' +
  '.tmg-ov h3{margin:0 0 10px;font-size:30px}' +
  '.tmg-ov p{margin:0 0 8px;font-size:15px;line-height:1.55;color:#cdd5e6}' +
  '.tmg-ov .newbest{color:#ffd34d;font-weight:700}' +
  '.tmg-btn{display:inline-block;margin-top:14px;background:#e5322d;color:#fff;border:none;border-radius:10px;padding:12px 34px;font-size:17px;font-weight:700;cursor:pointer}' +
  '.tmg-btn:hover{background:#c92824}' +
  '.tmg-hint{margin:10px 0 0;font-size:13px;color:#8a93a8}';

function ensureStyles() {
  if (document.getElementById('tmg-css')) return;
  var s = document.createElement('style');
  s.id = 'tmg-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}

/* ------------------------------------------------------------------ */
/* 4. Games hub                                                         */
/* ------------------------------------------------------------------ */
var HUB_GAMES = [
  { id: 'bubbles', icon: '\u25CB', title: 'Bubbles',
    desc: 'Letter bubbles float up from the deep. Type each letter to pop its bubble before it escapes off the top.',
    bestKey: 'game_bubbles' },
  { id: 'wordtris', icon: '\u25A6', title: 'WordTris',
    desc: 'Word blocks rain from the sky. The lowest word is armed — type its letters in order to clear it before it lands.',
    bestKey: 'game_wordtris' },
  { id: 'clouds', icon: '\u2601', title: 'Clouds',
    desc: 'Words drift by on passing clouds. Type a whole word to blow its cloud away. Backspace fixes typos, Esc clears.',
    bestKey: 'game_clouds' }
];

var activeCleanup = null;
function stopActiveGame() {
  if (activeCleanup) { try { activeCleanup(); } catch (e) {} activeCleanup = null; }
}

function mountHub(node) {
  ensureStyles();
  stopActiveGame();
  node.innerHTML = '';
  var hub = el('div', 'tmg-hub');
  hub.appendChild(el('h2', '', 'Typing Games'));
  hub.appendChild(el('p', 'sub', 'Three arcade games to sharpen your typing. All input is from your physical keyboard — no mouse needed once you start.'));
  var cards = el('div', 'tmg-cards');
  HUB_GAMES.forEach(function (g) {
    var best = getBest(g.bestKey, 0);
    var card = el('div', 'tmg-card');
    card.appendChild(el('div', 'icon', g.icon));
    card.appendChild(el('h3', '', esc(g.title)));
    card.appendChild(el('p', '', esc(g.desc)));
    card.appendChild(el('div', 'best', 'Best score: ' + esc(String(best))));
    var btn = el('button', 'tmg-btn', 'Play');
    btn.style.marginTop = '4px';
    btn.addEventListener('click', function () { showGame(node, g.id); });
    card.appendChild(btn);
    cards.appendChild(card);
  });
  hub.appendChild(cards);
  node.appendChild(hub);
}

// Game screen shell: back link + title + canvas + overlay host.
// Returns { canvas, ctx, overlay(html)->boxEl, clearOverlay(), onKey(fn)->off }.
function gameShell(node, title, w, h, hint) {
  ensureStyles();
  stopActiveGame();
  node.innerHTML = '';
  var screen = el('div', 'tmg-screen');
  var back = el('button', 'tmg-back', '\u2190 All games');
  back.addEventListener('click', function () { mountHub(node); });
  screen.appendChild(back);
  screen.appendChild(el('h2', 'tmg-title', esc(title)));
  var wrap = el('div', 'tmg-wrap');
  var canvas = document.createElement('canvas');
  canvas.className = 'tmg-canvas';
  canvas.width = w; canvas.height = h;
  wrap.appendChild(canvas);
  screen.appendChild(wrap);
  if (hint) screen.appendChild(el('p', 'tmg-hint', esc(hint)));
  node.appendChild(screen);

  var ctx = canvas.getContext('2d');
  var ov = null;
  function overlay(html) {
    clearOverlay();
    ov = el('div', 'tmg-ov', '<div class="box">' + html + '</div>');
    wrap.appendChild(ov);
    return ov;
  }
  function clearOverlay() { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); ov = null; }

  var offKey = null;
  function onKey(fn) {
    function h(e) {
      if (isEditableTarget(e)) return;
      if (e.key === ' ' || e.key === 'Spacebar') e.preventDefault(); // no page scroll
      fn(e);
    }
    document.addEventListener('keydown', h);
    offKey = function () { document.removeEventListener('keydown', h); };
  }

  // Pause on tab hide / window blur — shared across games.
  var blurCbs = [];
  function onAutoPause(cb) { blurCbs.push(cb); }
  function visHandler() { if (document.hidden) blurCbs.forEach(function (cb) { cb(); }); }
  function blurHandler() { blurCbs.forEach(function (cb) { cb(); }); }
  document.addEventListener('visibilitychange', visHandler);
  window.addEventListener('blur', blurHandler);

  activeCleanup = function () {
    if (offKey) offKey();
    document.removeEventListener('visibilitychange', visHandler);
    window.removeEventListener('blur', blurHandler);
  };
  return { canvas: canvas, ctx: ctx, overlay: overlay, clearOverlay: clearOverlay,
           onKey: onKey, onAutoPause: onAutoPause };
}

function showGame(node, id) {
  var mounts = { bubbles: mountBubbles, wordtris: mountWordtris, clouds: mountClouds };
  if (mounts[id]) mounts[id](node);
  else mountHub(node);
}

// HUD hearts drawn on canvas (no images).
function drawHearts(ctx, lives, x, y) {
  ctx.save();
  ctx.font = '20px system-ui, sans-serif';
  ctx.textBaseline = 'top';
  for (var i = 0; i < 3; i++) {
    ctx.fillStyle = i < lives ? '#ff4d5e' : 'rgba(255,255,255,.18)';
    ctx.fillText('\u2665', x + i * 24, y);
  }
  ctx.restore();
}
function drawScore(ctx, score, x, y, light) {
  ctx.save();
  ctx.font = '700 20px system-ui, sans-serif';
  ctx.textBaseline = 'top';
  ctx.fillStyle = light ? '#fff' : '#1a2233';
  ctx.fillText('Score: ' + score, x, y);
  ctx.restore();
}

/* ------------------------------------------------------------------ */
/* 5. Game: BUBBLES                                                     */
/*    Letter bubbles rise from the bottom. Type a bubble's letter to    */
/*    pop it (+10). A bubble reaching the top costs a life (3 lives).   */
/* ------------------------------------------------------------------ */
function mountBubbles(node) {
  var W = 720, H = 420;
  var shell = gameShell(node, 'Bubbles', W, H, 'Type the letter on a bubble to pop it. \u2022 P pauses.');
  var ctx = shell.ctx;
  var BEST_KEY = 'game_bubbles';

  var state = 'ready'; // ready | playing | paused | over
  var bubbles = [], particles = [];
  var score = 0, lives = 3;
  var spawnT = 0, flashT = 0, newBest = false;

  function difficulty() {
    return {
      interval: clamp(1.35 - score * 0.006, 0.42, 1.35), // seconds between spawns
      speed: clamp(46 + score * 0.65, 46, 175),          // rise speed px/s
      maxOn: clamp(3 + Math.floor(score / 60), 3, 9)     // concurrent bubbles
    };
  }
  function spawn() {
    var d = difficulty();
    if (bubbles.length >= d.maxOn) return;
    var r = rand(24, 34);
    var x = rand(r + 8, W - r - 8);
    // nudge away from existing bubbles to reduce overlap
    for (var tries = 0; tries < 8; tries++) {
      var ok = true;
      for (var i = 0; i < bubbles.length; i++) {
        if (Math.abs(bubbles[i].x - x) < r + bubbles[i].r + 6 && bubbles[i].y > H - 140) { ok = false; break; }
      }
      if (ok) break;
      x = rand(r + 8, W - r - 8);
    }
    bubbles.push({
      x: x, y: H + r,
      r: r,
      vy: -(d.speed * rand(0.85, 1.2)),
      letter: String.fromCharCode(97 + ((Math.random() * 26) | 0)),
      hue: (Math.random() * 360) | 0
    });
  }
  function popAt(x, y, hue) {
    for (var i = 0; i < 14; i++) {
      var a = Math.random() * Math.PI * 2, sp = rand(40, 190);
      particles.push({ x: x, y: y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
                       life: rand(0.3, 0.6), hue: hue });
    }
  }
  function startGame() {
    bubbles = []; particles = [];
    score = 0; lives = 3; spawnT = 0; flashT = 0; newBest = false;
    state = 'playing';
    shell.clearOverlay();
    loop.start();
  }
  function endGame() {
    state = 'over';
    loop.stop();
    var best = getBest(BEST_KEY, 0);
    if (score > best) { setBest(BEST_KEY, score); best = score; newBest = true; }
    shell.overlay(
      '<h3>Game over</h3>' +
      '<p>Score: <b>' + score + '</b></p>' +
      (newBest ? '<p class="newbest">\u2605 New best score! \u2605</p>'
               : '<p>Best: <b>' + best + '</b></p>') +
      '<button class="tmg-btn" id="tmg-again">Play again</button>'
    ).querySelector('#tmg-again').addEventListener('click', startGame);
  }
  function pauseGame() {
    if (state !== 'playing') return;
    state = 'paused';
    shell.overlay('<h3>Paused</h3><p>Press P or click resume to keep popping.</p>' +
                  '<button class="tmg-btn" id="tmg-resume">Resume</button>')
      .querySelector('#tmg-resume').addEventListener('click', resumeGame);
  }
  function resumeGame() {
    if (state !== 'paused') return;
    state = 'playing';
    shell.clearOverlay();
  }

  shell.overlay(
    '<h3>Bubbles</h3>' +
    '<p>Bubbles float up from the bottom. <b>Type the letter</b> on a bubble to pop it for <b>+10 points</b>.</p>' +
    '<p>If a bubble reaches the top you lose a life. You have <b>3 lives</b> \u2014 bubbles get faster and denser as you score.</p>' +
    '<button class="tmg-btn" id="tmg-start">Start</button>'
  ).querySelector('#tmg-start').addEventListener('click', startGame);

  shell.onKey(function (e) {
    if ((state === 'ready' || state === 'over') && (e.key === 'Enter' || e.key === ' ')) { startGame(); return; }
    if (e.key === 'p' || e.key === 'P' || e.key === 'Escape') {
      if (state === 'playing') pauseGame(); else if (state === 'paused') resumeGame();
      return;
    }
    if (state !== 'playing') return;
    if (e.key === 'Backspace') e.preventDefault();
    if (/^[a-z]$/i.test(e.key)) {
      var letter = e.key.toLowerCase();
      // pop the matching bubble closest to the bottom (most urgent)
      var idx = -1, bestY = -Infinity;
      for (var i = 0; i < bubbles.length; i++) {
        if (bubbles[i].letter === letter && bubbles[i].y > bestY) { bestY = bubbles[i].y; idx = i; }
      }
      if (idx >= 0) {
        var b = bubbles.splice(idx, 1)[0];
        popAt(b.x, b.y, b.hue);
        score += 10;
      }
    }
  });
  shell.onAutoPause(pauseGame);

  function update(dt) {
    // Animate scenery in every state except 'paused'; only 'playing'
    // advances scoring, spawning and life loss.
    var d = difficulty();
    if (state === 'playing') {
      spawnT -= dt;
      if (spawnT <= 0) { spawn(); spawnT = d.interval * rand(0.8, 1.2); }
    }
    if (flashT > 0) flashT -= dt;
    for (var i = bubbles.length - 1; i >= 0; i--) {
      var b = bubbles[i];
      b.y += b.vy * dt;
      if (b.y - b.r <= 0) {           // reached the top
        bubbles.splice(i, 1);
        if (state !== 'playing') continue; // demo bubbles behind overlays
        lives--;
        flashT = 0.35;
        if (lives <= 0) { endGame(); return; }
      }
    }
    for (var j = particles.length - 1; j >= 0; j--) {
      var p = particles[j];
      p.life -= dt;
      p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 160 * dt;
      if (p.life <= 0) particles.splice(j, 1);
    }
    if (state === 'ready' && bubbles.length < 4) { // gentle demo behind start overlay
      spawnT -= dt;
      if (spawnT <= 0) { spawn(); spawnT = 0.9; }
    }
  }
  function draw() {
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#0b1e4b'); g.addColorStop(1, '#123a7d');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // bubbles
    for (var i = 0; i < bubbles.length; i++) {
      var b = bubbles[i];
      var rg = ctx.createRadialGradient(b.x - b.r * 0.35, b.y - b.r * 0.35, b.r * 0.15, b.x, b.y, b.r);
      rg.addColorStop(0, 'hsla(' + b.hue + ',85%,72%,.85)');
      rg.addColorStop(1, 'hsla(' + b.hue + ',75%,45%,.35)');
      ctx.fillStyle = rg;
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'hsla(' + b.hue + ',90%,80%,.8)'; ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = '#fff';
      ctx.font = '700 ' + Math.round(b.r * 1.05) + 'px system-ui, sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(b.letter, b.x, b.y + 1);
    }
    // particles
    for (var j = 0; j < particles.length; j++) {
      var p = particles[j];
      ctx.fillStyle = 'hsla(' + p.hue + ',90%,70%,' + clamp(p.life * 2, 0, 1) + ')';
      ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, Math.PI * 2); ctx.fill();
    }
    // HUD
    ctx.textAlign = 'left';
    drawScore(ctx, score, 14, 12, true);
    drawHearts(ctx, lives, W - 86, 12);
    // escape flash
    if (flashT > 0) {
      ctx.strokeStyle = 'rgba(255,60,60,' + clamp(flashT * 2, 0, 0.9) + ')';
      ctx.lineWidth = 10;
      ctx.strokeRect(5, 5, W - 10, H - 10);
    }
  }
  var loop = makeLoop(update, draw);
  loop.start(); // runs in every state; update() gates on state internally
  var prevCleanup = activeCleanup;
  activeCleanup = function () {
    loop.stop();
    if (prevCleanup) prevCleanup();
  };
}

/* ------------------------------------------------------------------ */
/* 6. Game: WORDTRIS                                                    */
/*    Word blocks fall from the top. Only the LOWEST (active) word can  */
/*    be typed: letters must arrive in order. Clearing a word scores    */
/*    +10 per letter plus a flat clear bonus. A word touching the       */
/*    bottom costs a life (3 lives). Fall speed ramps with score.       */
/* ------------------------------------------------------------------ */
var TM_WORDS = ('up ox be do go he if in is it me my no of on or so to us we ' +
  'air ant ape arc arm art ask ate bad bag bar bat bay bed bee big bin bit ' +
  'bog box boy bus cab cake calm camp card carry catch chair ' +
  'chase cheap cheese chest chief child choir chose civil claim class clean ' +
  'clear clerk click cliff climb clock cloud coach coast color ' +
  'comet coral could count court cover crack craft crash crazy cream ' +
  'crime cross crowd crown daily dance death delay depth diary ' +
  'dozen draft drain drama dream dress drink drive eager early earth ' +
  'eight elbow elder elect empty enemy enjoy enter entry equal ' +
  'error essay event every exact exist extra fancy fault favor ' +
  'feast fence fever fiber field fiery fifty fight final first ' +
  'flame flash fleet flesh float floor flour fluid focus force ' +
  'frame fresh frost fruit giant given glass globe glory gloves ' +
  'grace grade grain grand grant grape grass great green greet').split(' ')
  .filter(function (w) { return w.length >= 2 && w.length <= 6; });

function mountWordtris(node) {
  var W = 480, H = 520, FLOOR = H - 56;
  var shell = gameShell(node, 'WordTris', W, H, 'Type the highlighted (lowest) word letter by letter. \u2022 P pauses.');
  var ctx = shell.ctx;
  var BEST_KEY = 'game_wordtris';

  var state = 'ready';
  var words = []; // {x,y,word,typed,vy,errT}
  var score = 0, lives = 3, flashT = 0, newBest = false;
  var MAX_WORDS = 4;

  function fallSpeed() { return clamp(26 + score * 0.4, 26, 125); }
  function spawn() {
    var word = pick(TM_WORDS);
    var bw = 18 + word.length * 22;
    words.push({
      x: rand(12, Math.max(13, W - bw - 12)),
      y: -46,
      word: word, typed: 0,
      vy: fallSpeed() * rand(0.9, 1.12),
      errT: 0
    });
  }
  function activeWord() { // the lowest word is the armed one
    var a = null;
    for (var i = 0; i < words.length; i++) {
      if (!a || words[i].y > a.y) a = words[i];
    }
    return a;
  }
  function startGame() {
    words = []; score = 0; lives = 3; flashT = 0; newBest = false;
    for (var i = 0; i < MAX_WORDS; i++) { spawn(); words[i].y = -46 - i * rand(90, 150); }
    state = 'playing';
    shell.clearOverlay();
    loop.start();
  }
  function endGame() {
    state = 'over';
    loop.stop();
    var best = getBest(BEST_KEY, 0);
    if (score > best) { setBest(BEST_KEY, score); best = score; newBest = true; }
    shell.overlay(
      '<h3>Game over</h3>' +
      '<p>Score: <b>' + score + '</b></p>' +
      (newBest ? '<p class="newbest">\u2605 New best score! \u2605</p>'
               : '<p>Best: <b>' + best + '</b></p>') +
      '<button class="tmg-btn" id="tmg-again">Play again</button>'
    ).querySelector('#tmg-again').addEventListener('click', startGame);
  }
  function pauseGame() {
    if (state !== 'playing') return;
    state = 'paused';
    shell.overlay('<h3>Paused</h3><p>Press P or click resume to continue.</p>' +
                  '<button class="tmg-btn" id="tmg-resume">Resume</button>')
      .querySelector('#tmg-resume').addEventListener('click', resumeGame);
  }
  function resumeGame() {
    if (state !== 'paused') return;
    state = 'playing';
    shell.clearOverlay();
  }

  shell.overlay(
    '<h3>WordTris</h3>' +
    '<p>Word blocks fall from the sky. The <b>lowest word glows</b> \u2014 type its letters <b>in order</b> to clear it for <b>+10 per letter</b> plus a clear bonus.</p>' +
    '<p>A word touching the floor costs a life. You have <b>3 lives</b>.</p>' +
    '<button class="tmg-btn" id="tmg-start">Start</button>'
  ).querySelector('#tmg-start').addEventListener('click', startGame);

  shell.onKey(function (e) {
    if ((state === 'ready' || state === 'over') && (e.key === 'Enter' || e.key === ' ')) { startGame(); return; }
    if (e.key === 'p' || e.key === 'P' || e.key === 'Escape') {
      if (state === 'playing') pauseGame(); else if (state === 'paused') resumeGame();
      return;
    }
    if (state !== 'playing') return;
    if (e.key === 'Backspace') e.preventDefault();
    if (/^[a-z]$/i.test(e.key)) {
      var a = activeWord();
      if (!a) return;
      var letter = e.key.toLowerCase();
      if (letter === a.word.charAt(a.typed)) {
        a.typed++;
        score += 10;
        if (a.typed >= a.word.length) { // word cleared
          score += 20;
          words.splice(words.indexOf(a), 1);
        }
      } else {
        a.errT = 0.3; // wrong key: shake/flash the armed word, no penalty
      }
    }
  });
  shell.onAutoPause(pauseGame);

  function update(dt) {
    if (state !== 'playing') return;
    if (flashT > 0) flashT -= dt;
    for (var i = words.length - 1; i >= 0; i--) {
      var w = words[i];
      w.y += w.vy * dt;
      if (w.errT > 0) w.errT -= dt;
      if (w.y >= FLOOR) { // landed
        words.splice(i, 1);
        lives--;
        flashT = 0.35;
        if (lives <= 0) { endGame(); return; }
      }
    }
    while (words.length < MAX_WORDS) spawn();
  }
  function drawWord(w, isActive) {
    var fs = 22, padX = 12, lh = 30;
    ctx.font = '700 ' + fs + 'px ui-monospace, Menlo, Consolas, monospace';
    var tw = ctx.measureText(w.word).width;
    var bw = tw + padX * 2, bx = w.x, by = w.y - 4;
    var shake = w.errT > 0 ? Math.sin(w.errT * 60) * 4 : 0;
    bx += shake;
    ctx.save();
    if (isActive) { ctx.shadowColor = '#ffd34d'; ctx.shadowBlur = 14; }
    ctx.fillStyle = w.errT > 0 ? '#7d2430' : (isActive ? '#2f6fed' : '#3a4663');
    roundRect(ctx, bx, by, bw, lh + 8, 9);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = isActive ? '#ffd34d' : 'rgba(255,255,255,.25)';
    ctx.lineWidth = isActive ? 2.5 : 1.5;
    roundRect(ctx, bx, by, bw, lh + 8, 9);
    ctx.stroke();
    // letters: typed portion green, next letter underlined
    ctx.textBaseline = 'middle';
    var cx = bx + padX;
    for (var i = 0; i < w.word.length; i++) {
      var ch = w.word.charAt(i);
      var cw = ctx.measureText(ch).width;
      ctx.fillStyle = i < w.typed ? '#7dff9a' : '#fff';
      ctx.textAlign = 'left';
      ctx.fillText(ch, cx, by + (lh + 8) / 2 + 1);
      if (isActive && i === w.typed) {
        ctx.fillStyle = '#ffd34d';
        ctx.fillRect(cx, by + lh + 2, cw, 3);
      }
      cx += cw;
    }
    ctx.restore();
  }
  function draw() {
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#101528'); g.addColorStop(1, '#1d2a52');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // faint guide columns
    ctx.strokeStyle = 'rgba(255,255,255,.05)'; ctx.lineWidth = 1;
    for (var gx = 40; gx < W; gx += 40) { ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke(); }
    var a = state === 'playing' || state === 'paused' ? activeWord() : null;
    for (var i = 0; i < words.length; i++) drawWord(words[i], words[i] === a);
    // floor
    ctx.fillStyle = 'rgba(255,77,94,.35)';
    ctx.fillRect(0, FLOOR + 34, W, H - FLOOR - 34);
    ctx.fillStyle = '#ff4d5e';
    ctx.fillRect(0, FLOOR + 32, W, 2);
    // HUD
    ctx.textAlign = 'left';
    drawScore(ctx, score, 14, 12, true);
    drawHearts(ctx, lives, W - 86, 12);
    if (flashT > 0) {
      ctx.strokeStyle = 'rgba(255,60,60,' + clamp(flashT * 2, 0, 0.9) + ')';
      ctx.lineWidth = 10;
      ctx.strokeRect(5, 5, W - 10, H - 10);
    }
  }
  var loop = makeLoop(update, draw);
  loop.start();
  var prevCleanup = activeCleanup;
  activeCleanup = function () {
    loop.stop();
    if (prevCleanup) prevCleanup();
  };
}

/* ------------------------------------------------------------------ */
/* 7. Game: CLOUDS                                                      */
/*    Word clouds drift right-to-left. Typed letters accumulate in a    */
/*    buffer shown at the bottom; when the buffer EXACTLY matches a     */
/*    visible word, that cloud is cleared (+10 per letter). Backspace   */
/*    trims the buffer, Esc clears it. A cloud escaping off the left    */
/*    edge costs a life (3 lives).                                      */
/* ------------------------------------------------------------------ */
function mountClouds(node) {
  var W = 720, H = 420;
  var shell = gameShell(node, 'Clouds', W, H, 'Type a cloud\u2019s word to clear it. \u2022 Backspace fixes \u2022 Esc clears \u2022 P pauses.');
  var ctx = shell.ctx;
  var BEST_KEY = 'game_clouds';

  var state = 'ready';
  var clouds = []; // {x,y,word,speed,scale,puffs[]}
  var buffer = '';
  var score = 0, lives = 3, spawnT = 0, flashT = 0, newBest = false;
  var invalidT = 0; // buffer flash timer when buffer matches no word prefix

  function difficulty() {
    return {
      interval: clamp(2.0 - score * 0.008, 0.9, 2.0),
      speed: clamp(42 + score * 0.5, 42, 130),
      maxOn: clamp(3 + Math.floor(score / 80), 3, 7)
    };
  }
  function makePuffs(scale) {
    // precomputed blob: circles relative to cloud origin, scaled at draw
    return [
      { dx: 0, dy: 0, r: 26 }, { dx: 26, dy: -10, r: 32 }, { dx: 54, dy: -2, r: 26 },
      { dx: 80, dy: 4, r: 20 }, { dx: -26, dy: 4, r: 20 }, { dx: 40, dy: 12, r: 24 }
    ].map(function (p) { return { dx: p.dx * scale, dy: p.dy * scale, r: p.r * scale }; });
  }
  function spawn() {
    var d = difficulty();
    if (clouds.length >= d.maxOn) return;
    var word = pick(TM_WORDS);
    var scale = rand(0.85, 1.25);
    var y = rand(70, H - 170);
    // stagger lanes a little to reduce overlap
    for (var tries = 0; tries < 8; tries++) {
      var ok = true;
      for (var i = 0; i < clouds.length; i++) {
        if (Math.abs(clouds[i].y - y) < 70 && clouds[i].x > W - 260) { ok = false; break; }
      }
      if (ok) break;
      y = rand(70, H - 170);
    }
    clouds.push({
      x: W + 90, y: y, word: word,
      speed: -(d.speed * rand(0.8, 1.25)),
      scale: scale, puffs: makePuffs(scale),
      wob: Math.random() * Math.PI * 2
    });
  }
  // Does any visible word start with the current buffer? Used to tint it red.
  function bufferValid() {
    if (!buffer) return true;
    for (var i = 0; i < clouds.length; i++) {
      if (clouds[i].word.indexOf(buffer) === 0) return true;
    }
    return false;
  }
  function startGame() {
    clouds = []; buffer = '';
    score = 0; lives = 3; spawnT = 0; flashT = 0; invalidT = 0; newBest = false;
    for (var i = 0; i < 3; i++) { spawn(); clouds[i].x = rand(W * 0.35, W + 60); }
    state = 'playing';
    shell.clearOverlay();
    loop.start();
  }
  function endGame() {
    state = 'over';
    loop.stop();
    var best = getBest(BEST_KEY, 0);
    if (score > best) { setBest(BEST_KEY, score); best = score; newBest = true; }
    shell.overlay(
      '<h3>Game over</h3>' +
      '<p>Score: <b>' + score + '</b></p>' +
      (newBest ? '<p class="newbest">\u2605 New best score! \u2605</p>'
               : '<p>Best: <b>' + best + '</b></p>') +
      '<button class="tmg-btn" id="tmg-again">Play again</button>'
    ).querySelector('#tmg-again').addEventListener('click', startGame);
  }
  function pauseGame() {
    if (state !== 'playing') return;
    state = 'paused';
    shell.overlay('<h3>Paused</h3><p>Press P or click resume to continue.</p>' +
                  '<button class="tmg-btn" id="tmg-resume">Resume</button>')
      .querySelector('#tmg-resume').addEventListener('click', resumeGame);
  }
  function resumeGame() {
    if (state !== 'paused') return;
    state = 'playing';
    shell.clearOverlay();
  }

  shell.overlay(
    '<h3>Clouds</h3>' +
    '<p>Words drift by on clouds. <b>Type a whole word</b> to clear its cloud for <b>+10 per letter</b>. ' +
    'Your typing appears in the bar below \u2014 <b>Backspace</b> fixes typos, <b>Esc</b> clears it.</p>' +
    '<p>A cloud escaping off the left costs a life. You have <b>3 lives</b>.</p>' +
    '<button class="tmg-btn" id="tmg-start">Start</button>'
  ).querySelector('#tmg-start').addEventListener('click', startGame);

  shell.onKey(function (e) {
    if ((state === 'ready' || state === 'over') && (e.key === 'Enter' || e.key === ' ')) { startGame(); return; }
    if (e.key === 'p' || e.key === 'P') {
      if (state === 'playing') pauseGame(); else if (state === 'paused') resumeGame();
      return;
    }
    if (state === 'paused' && e.key === 'Escape') { resumeGame(); return; }
    if (state !== 'playing') return;
    if (e.key === 'Escape') { buffer = ''; return; }
    if (e.key === 'Backspace') { e.preventDefault(); buffer = buffer.slice(0, -1); return; }
    if (/^[a-z]$/i.test(e.key)) {
      buffer += e.key.toLowerCase();
      // Exact match against a visible word clears that cloud.
      // Prefer the leftmost (most urgent) matching cloud.
      var idx = -1;
      for (var i = 0; i < clouds.length; i++) {
        if (clouds[i].word === buffer && (idx < 0 || clouds[i].x < clouds[idx].x)) idx = i;
      }
      if (idx >= 0) {
        score += 10 * buffer.length;
        clouds.splice(idx, 1);
        buffer = '';
      } else if (!bufferValid()) {
        invalidT = 0.4; // brief red tint: buffer matches nothing
      }
    }
  });
  shell.onAutoPause(pauseGame);

  function update(dt) {
    if (state !== 'playing') return;
    var d = difficulty();
    spawnT -= dt;
    if (spawnT <= 0) { spawn(); spawnT = d.interval * rand(0.8, 1.2); }
    if (flashT > 0) flashT -= dt;
    if (invalidT > 0) invalidT -= dt;
    for (var i = clouds.length - 1; i >= 0; i--) {
      var c = clouds[i];
      c.x += c.speed * dt;
      c.wob += dt * 1.6;
      if (c.x + 110 * c.scale < 0) { // escaped off the left
        clouds.splice(i, 1);
        lives--;
        flashT = 0.35;
        if (lives <= 0) { endGame(); return; }
      }
    }
  }
  function drawCloud(c) {
    var bob = Math.sin(c.wob) * 5;
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,.94)';
    for (var i = 0; i < c.puffs.length; i++) {
      var p = c.puffs[i];
      ctx.beginPath();
      ctx.arc(c.x + p.dx, c.y + p.dy + bob, p.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = 'rgba(160,180,210,.5)';
    ctx.beginPath();
    ctx.ellipse(c.x + 28 * c.scale, c.y + 26 * c.scale + bob, 46 * c.scale, 10 * c.scale, 0, 0, Math.PI * 2);
    ctx.fill();
    // word under the cloud
    ctx.font = '700 ' + Math.round(21 * c.scale) + 'px ui-monospace, Menlo, Consolas, monospace';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillStyle = '#274060';
    ctx.fillText(c.word, c.x + 28 * c.scale, c.y + 34 * c.scale + bob);
    ctx.restore();
  }
  function draw() {
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#7ec8f7'); g.addColorStop(0.7, '#bfe3fb'); g.addColorStop(1, '#dff1fd');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // sun
    ctx.fillStyle = '#ffd94d';
    ctx.beginPath(); ctx.arc(W - 90, 64, 30, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(255,217,77,.3)';
    ctx.beginPath(); ctx.arc(W - 90, 64, 44, 0, Math.PI * 2); ctx.fill();
    // distant hills
    ctx.fillStyle = '#a8d5a2';
    ctx.beginPath();
    ctx.moveTo(0, H); ctx.quadraticCurveTo(W * 0.25, H - 120, W * 0.55, H - 40);
    ctx.quadraticCurveTo(W * 0.8, H + 10, W, H - 60);
    ctx.lineTo(W, H); ctx.closePath(); ctx.fill();
    for (var i = 0; i < clouds.length; i++) drawCloud(clouds[i]);
    // buffer bar
    var bw = 420, bx = (W - bw) / 2, by = H - 52;
    ctx.fillStyle = invalidT > 0 ? 'rgba(200,40,50,.92)' : 'rgba(10,25,50,.82)';
    roundRect(ctx, bx, by, bw, 38, 10);
    ctx.fill();
    ctx.strokeStyle = invalidT > 0 ? '#ff8080' : 'rgba(255,255,255,.35)';
    ctx.lineWidth = 2;
    roundRect(ctx, bx, by, bw, 38, 10);
    ctx.stroke();
    ctx.font = '700 22px ui-monospace, Menlo, Consolas, monospace';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#fff';
    var label = buffer || (state === 'playing' ? 'type a word\u2026' : '');
    ctx.globalAlpha = buffer ? 1 : 0.45;
    ctx.fillText(label, W / 2, by + 20);
    ctx.globalAlpha = 1;
    // HUD
    ctx.textAlign = 'left';
    drawScore(ctx, score, 14, 12, false);
    ctx.save();
    ctx.font = '20px system-ui, sans-serif'; ctx.textBaseline = 'top';
    for (var h = 0; h < 3; h++) {
      ctx.fillStyle = h < lives ? '#ff4d5e' : 'rgba(120,140,170,.35)';
      ctx.fillText('\u2665', W - 86 + h * 24, 12);
    }
    ctx.restore();
    if (flashT > 0) {
      ctx.strokeStyle = 'rgba(255,60,60,' + clamp(flashT * 2, 0, 0.9) + ')';
      ctx.lineWidth = 10;
      ctx.strokeRect(5, 5, W - 10, H - 10);
    }
  }
  var loop = makeLoop(update, draw);
  loop.start();
  var prevCleanup = activeCleanup;
  activeCleanup = function () {
    loop.stop();
    if (prevCleanup) prevCleanup();
  };
}

/* ------------------------------------------------------------------ */
/* 8. View registration                                                 */
/* ------------------------------------------------------------------ */
if (TM && TM.registerView) {
  TM.registerView('games', {
    mount: function (el, params) {
      if (params && params.game) showGame(el, params.game);
      else mountHub(el);
    },
    unmount: function () { stopActiveGame(); }
  });
}

})();
