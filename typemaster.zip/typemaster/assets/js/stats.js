/* TypingMaster 11 clone — stats.js (workstream 5)
 * Registers TWO views with window.TM (defined by app.js, which loads first):
 *   'stats'  — progress dashboard: summary cards, bests, charts, heatmap, stars, sessions table, reset.
 *   'review' — custom weak-key drill built from stored keyErrors, driven by TM.Engine.startCustom.
 *
 * Vanilla JS, zero external requests, works from file://.
 * Storage keys (under the 'tm11.' localStorage prefix) READ here:
 *   'sessions'  — array of {ts, view, lesson, drill, durationSec, grossWpm, netWpm, accuracy, errors, keystrokes}
 *   'bests'     — object, e.g. bests['test_1'] -> {netWpm, accuracy}; also game_bubbles / game_wordtris / game_clouds
 *   'keyErrors' — {char: count}
 *   'stars'     — {'l0d0': 3} via TM.getStars()
 * Storage WRITTEN here: review drills log via TM.appendSession(...); engine writes key errors via TM.recordKeyErrors(...)
 * (the engine calls those internally for custom drills — this file only needs appendSession for the drill result).
 */
(function () {
  'use strict';

  // ---------------------------------------------------------------- helpers

  // Cheap guards: TM is guaranteed by the contract, but workstreams may load
  // out of order during development; fail loudly-free instead of crashing.
  var TM = window.TM || null;
  if (!TM) return; // app.js not loaded yet — nothing to register with.

  function load(key, fallback) {
    try { return TM.load(key, fallback); } catch (e) { return fallback; }
  }
  function num(v, dflt) {
    v = Number(v);
    return isFinite(v) ? v : (dflt === undefined ? 0 : dflt);
  }
  function esc(s) {
    try { return TM.escapeHtml(String(s)); } catch (e) { return String(s).replace(/[&<>"']/g, function (c) { return '&#' + c.charCodeAt(0) + ';'; }); }
  }
  function fmtTime(sec) {
    try { return TM.fmtTime(sec); } catch (e) { return Math.round(sec / 60) + 'm'; }
  }
  function mk(tag, cls, html) {
    try { return TM.el(tag, cls, html); } catch (e) {
      var e2 = document.createElement(tag);
      if (cls) e2.className = cls;
      if (html !== undefined) e2.innerHTML = html;
      return e2;
    }
  }
  function fmtDate(ts) {
    // Local timezone rendering of a session timestamp.
    try {
      return new Date(ts).toLocaleString(undefined, {
        year: 'numeric', month: 'short', day: 'numeric',
        hour: '2-digit', minute: '2-digit'
      });
    } catch (e) { return String(ts); }
  }

  // Deterministic pseudo-random (LCG) so the review drill text is stable for a
  // given set of weak keys — no Math.random(), reproducible drill content.
  function seededRand(seed) {
    var s = seed >>> 0 || 1;
    return function () {
      s = (s * 1664525 + 1013904223) >>> 0;
      return s / 4294967296;
    };
  }

  // ------------------------------------------------- canvas chart plumbing

  // Set up a canvas for crisp rendering on high-DPI screens: size the backing
  // store by devicePixelRatio and scale the 2D context so 1 CSS px = 1 unit.
  function setupCanvas(canvas, cssW, cssH) {
    var dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(cssW * dpr);
    canvas.height = Math.round(cssH * dpr);
    canvas.style.width = cssW + 'px';
    canvas.style.height = cssH + 'px';
    var ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return ctx;
  }

  function drawLineChart(canvas, sessions) {
    // sessions: chronological array (already sorted ascending by ts) of
    // sessions with .netWpm. Draws axes, min/max labels, polyline and dots.
    var W = 640, H = 220, padL = 44, padR = 14, padT = 18, padB = 30;
    var ctx = setupCanvas(canvas, W, H);
    var vals = sessions.map(function (s) { return num(s.netWpm); });
    var min = Math.min.apply(null, vals), max = Math.max.apply(null, vals);
    if (min === max) { min = Math.max(0, min - 5); max = max + 5; }
    var iw = W - padL - padR, ih = H - padT - padB;
    function x(i) { return padL + (vals.length === 1 ? iw / 2 : iw * i / (vals.length - 1)); }
    function y(v) { return padT + ih * (1 - (v - min) / (max - min)); }

    ctx.clearRect(0, 0, W, H);
    ctx.font = '11px sans-serif'; ctx.fillStyle = '#8a8a8a';
    ctx.strokeStyle = '#e3e3e3'; ctx.lineWidth = 1;
    // Horizontal gridlines at min / mid / max.
    [min, (min + max) / 2, max].forEach(function (v) {
      var yy = y(v);
      ctx.beginPath(); ctx.moveTo(padL, yy); ctx.lineTo(W - padR, yy); ctx.stroke();
      ctx.fillText(Math.round(v) + ' WPM', 4, yy + 4);
    });
    // X axis.
    ctx.strokeStyle = '#c9c9c9';
    ctx.beginPath(); ctx.moveTo(padL, H - padB); ctx.lineTo(W - padR, H - padB); ctx.stroke();
    ctx.fillStyle = '#8a8a8a';
    ctx.fillText('oldest', padL, H - 10);
    ctx.fillText('newest', W - padR - 46, H - 10);

    // Polyline.
    ctx.strokeStyle = '#1a73e8'; ctx.lineWidth = 2; ctx.lineJoin = 'round';
    ctx.beginPath();
    vals.forEach(function (v, i) { i ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v)); });
    ctx.stroke();
    // Dots.
    ctx.fillStyle = '#1a73e8';
    vals.forEach(function (v, i) { ctx.beginPath(); ctx.arc(x(i), y(v), 3, 0, 6.2832); ctx.fill(); });
  }

  function drawAccuracyBars(canvas, sessions) {
    // Last-N sessions as vertical bars, 0–100% scale, value labels on top.
    var W = 640, H = 200, padL = 44, padR = 14, padT = 26, padB = 30;
    var ctx = setupCanvas(canvas, W, H);
    var vals = sessions.map(function (s) { return Math.max(0, Math.min(100, num(s.accuracy))); });
    var n = vals.length, iw = W - padL - padR, ih = H - padT - padB;
    var slot = iw / n, bw = Math.max(6, Math.min(28, slot * 0.55));

    ctx.clearRect(0, 0, W, H);
    ctx.font = '11px sans-serif';
    // Gridlines at 0/50/100.
    [0, 50, 100].forEach(function (v) {
      var yy = padT + ih * (1 - v / 100);
      ctx.strokeStyle = '#e3e3e3'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(padL, yy); ctx.lineTo(W - padR, yy); ctx.stroke();
      ctx.fillStyle = '#8a8a8a'; ctx.fillText(v + '%', 6, yy + 4);
    });
    vals.forEach(function (v, i) {
      var bh = ih * v / 100;
      var bx = padL + slot * i + (slot - bw) / 2;
      var by = padT + ih - bh;
      // Color: red < 85%, amber < 95%, green otherwise.
      ctx.fillStyle = v < 85 ? '#e5322d' : (v < 95 ? '#f5a623' : '#2e9e44');
      ctx.fillRect(bx, by, bw, bh);
      ctx.fillStyle = '#666';
      ctx.textAlign = 'center';
      ctx.fillText(Math.round(v) + '%', bx + bw / 2, by - 5);
      ctx.textAlign = 'left';
    });
  }

  // ------------------------------------------------------- 'stats' view

  function statsUnmount() { /* charts/keyboard are static DOM; nothing to tear down */ }

  function mountStats(el) {
    el.innerHTML = '';
    var wrap = mk('div', 'tm-stats');
    el.appendChild(wrap);

    var h = mk('h2', 'tm-view-title', 'Statistics');
    wrap.appendChild(h);

    var sessions = load('sessions', []);
    if (!Array.isArray(sessions)) sessions = [];
    // Chronological order (oldest → newest) for the time-based charts.
    var chrono = sessions.slice().sort(function (a, b) { return num(a.ts) - num(b.ts); });

    if (!sessions.length) {
      wrap.appendChild(mk('p', 'tm-empty', 'No sessions yet — complete a drill or test to see statistics.'));
      return;
    }

    // ---- Summary cards
    var totalSec = sessions.reduce(function (a, s) { return a + num(s.durationSec); }, 0);
    var totalKeys = sessions.reduce(function (a, s) { return a + num(s.keystrokes); }, 0);
    var last20 = chrono.slice(-20);
    var avgWpm = last20.reduce(function (a, s) { return a + num(s.netWpm); }, 0) / last20.length;
    var avgAcc = last20.reduce(function (a, s) { return a + num(s.accuracy); }, 0) / last20.length;

    var cards = mk('div', 'tm-cards');
    [
      ['Sessions', String(sessions.length)],
      ['Time typed', fmtTime(totalSec)],
      ['Avg net WPM (last 20)', avgWpm.toFixed(1)],
      ['Avg accuracy (last 20)', avgAcc.toFixed(1) + '%'],
      ['Keystrokes', totalKeys.toLocaleString()]
    ].forEach(function (c) {
      var card = mk('div', 'tm-card',
        '<div class="tm-card-value">' + esc(c[1]) + '</div>' +
        '<div class="tm-card-label">' + esc(c[0]) + '</div>');
      cards.appendChild(card);
    });
    wrap.appendChild(cards);

    // ---- Personal bests
    var bests = load('bests', {}) || {};
    var bestCard = mk('div', 'tm-panel');
    bestCard.appendChild(mk('h3', '', 'Personal bests'));
    var bestList = mk('ul', 'tm-best-list');
    function bestRow(label, b) {
      var li = mk('li', '',
        '<span>' + esc(label) + '</span>' +
        (b && isFinite(num(b.netWpm))
          ? '<strong>' + esc(num(b.netWpm).toFixed(1)) + ' WPM · ' + esc(num(b.accuracy).toFixed(1)) + '%</strong>'
          : '<span class="tm-muted">—</span>'));
      bestList.appendChild(li);
    }
    bestRow('1 minute test', bests['test_1']);
    bestRow('2 minute test', bests['test_2']);
    bestRow('5 minute test', bests['test_5']);
    bestRow('10 minute test', bests['test_10']);
    bestRow('Bubbles game', bests['game_bubbles']);
    bestRow('WordTris game', bests['game_wordtris']);
    bestRow('Word Clouds game', bests['game_clouds']);
    var bestDrillWpm = sessions.reduce(function (a, s) { return Math.max(a, num(s.netWpm)); }, 0);
    var li = mk('li', '',
      '<span>Best drill net WPM</span>' +
      '<strong>' + esc(bestDrillWpm.toFixed(1)) + ' WPM</strong>');
    bestList.appendChild(li);
    bestCard.appendChild(bestList);
    wrap.appendChild(bestCard);

    // ---- WPM over time (line chart, last 50)
    var chartPanel = mk('div', 'tm-panel');
    chartPanel.appendChild(mk('h3', '', 'Net WPM over time (last 50 sessions)'));
    var lineCanvas = document.createElement('canvas');
    lineCanvas.setAttribute('role', 'img');
    lineCanvas.setAttribute('aria-label', 'Line chart of net WPM per session');
    chartPanel.appendChild(lineCanvas);
    wrap.appendChild(chartPanel);
    drawLineChart(lineCanvas, chrono.slice(-50));

    // ---- Accuracy bars (last 20)
    var accPanel = mk('div', 'tm-panel');
    accPanel.appendChild(mk('h3', '', 'Accuracy per session (last 20)'));
    var barCanvas = document.createElement('canvas');
    barCanvas.setAttribute('role', 'img');
    barCanvas.setAttribute('aria-label', 'Bar chart of accuracy per session');
    accPanel.appendChild(barCanvas);
    wrap.appendChild(accPanel);
    drawAccuracyBars(barCanvas, chrono.slice(-20));

    // ---- Problem-key heatmap
    var keyErrors = load('keyErrors', {}) || {};
    var heatPanel = mk('div', 'tm-panel');
    heatPanel.appendChild(mk('h3', '', 'Problem keys'));
    var kbHost = mk('div', 'tm-heatmap-kb');
    heatPanel.appendChild(kbHost);
    if (TM.buildKeyboard) {
      var kb = TM.buildKeyboard(kbHost);
      // Style keys directly — do not use kb.setNext (no "next key" in stats).
      // Intensity: errors / maxErrors, sqrt-scaled so a single huge count
      // doesn't wash out smaller ones; alpha 0.08 → 0.85 over a white base.
      var counts = Object.keys(keyErrors).map(function (k) { return num(keyErrors[k]); });
      var maxErr = Math.max.apply(null, counts.concat([0]));
      var keys = kbHost.querySelectorAll('.key');
      for (var qi = 0; qi < keys.length; qi++) {
        var keyEl = keys[qi];
        var ch = keyEl.getAttribute('data-key'); // component sets data-key=char
        if (ch == null) continue;
        var c = num(keyErrors[ch] || keyErrors[ch.toLowerCase()], 0);
        if (c > 0 && maxErr > 0) {
          var t = Math.sqrt(c / maxErr);
          var alpha = 0.08 + 0.77 * t;
          keyEl.style.background = 'rgba(229, 50, 45, ' + alpha.toFixed(2) + ')';
          keyEl.style.borderColor = '#c02823';
          keyEl.title = ch + ': ' + c + ' errors';
        }
      }
    }
    heatPanel.appendChild(mk('p', 'tm-legend', 'more errors → darker red'));
    wrap.appendChild(heatPanel);

    // ---- Per-lesson stars
    var lessons = (window.TMData && Array.isArray(window.TMData.lessons)) ? window.TMData.lessons : [];
    var stars = {};
    try { stars = TM.getStars() || {}; } catch (e) { stars = {}; }
    if (lessons.length) {
      var starPanel = mk('div', 'tm-panel');
      starPanel.appendChild(mk('h3', '', 'Lesson stars'));
      var grid = mk('div', 'tm-stars-grid');
      lessons.forEach(function (lesson, liIdx) {
        var row = mk('div', 'tm-stars-row');
        row.appendChild(mk('div', 'tm-stars-lesson', esc(lesson.title || ('Lesson ' + (liIdx + 1)))));
        var drills = Array.isArray(lesson.drills) ? lesson.drills : [];
        drills.forEach(function (drill, di) {
          var n = num(stars['l' + liIdx + 'd' + di], 0);
          var cell = mk('div', 'tm-stars-cell', '★'.repeat(Math.max(0, Math.min(3, Math.round(n)))));
          cell.title = (drill.title || ('Drill ' + (di + 1))) + ': ' + n + ' star' + (n === 1 ? '' : 's');
          row.appendChild(cell);
        });
        grid.appendChild(row);
      });
      starPanel.appendChild(grid);
      wrap.appendChild(starPanel);
    }

    // ---- Sessions table (last 15, newest first)
    var tblPanel = mk('div', 'tm-panel');
    tblPanel.appendChild(mk('h3', '', 'Recent sessions'));
    var table = mk('table', 'tm-table',
      '<thead><tr>' +
      '<th>Date</th><th>Type</th><th>Lesson / drill</th>' +
      '<th>Net WPM</th><th>Accuracy</th><th>Errors</th>' +
      '</tr></thead>');
    var tbody = document.createElement('tbody');
    chrono.slice(-15).reverse().forEach(function (s) {
      var tr = document.createElement('tr');
      tr.appendChild(mk('td', '', esc(fmtDate(s.ts))));
      tr.appendChild(mk('td', '', esc(typeLabel(s.view))));
      tr.appendChild(mk('td', '', esc(lessonDrillLabel(s))));
      tr.appendChild(mk('td', '', esc(num(s.netWpm).toFixed(1))));
      tr.appendChild(mk('td', '', esc(num(s.accuracy).toFixed(1) + '%')));
      tr.appendChild(mk('td', '', esc(String(Math.round(num(s.errors))))));
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    tblPanel.appendChild(table);
    wrap.appendChild(tblPanel);

    // ---- Reset all data
    var resetBtn = mk('button', 'tm-btn tm-btn-danger', 'Reset all data');
    resetBtn.type = 'button';
    resetBtn.addEventListener('click', function () {
      if (!window.confirm('Delete ALL TypingMaster data (sessions, bests, stars)? This cannot be undone.')) return;
      try {
        var doomed = [];
        for (var i = 0; i < window.localStorage.length; i++) {
          var k = window.localStorage.key(i);
          if (k && k.indexOf('tm11.') === 0) doomed.push(k);
        }
        doomed.forEach(function (k) { window.localStorage.removeItem(k); });
      } catch (e) { /* storage unavailable — nothing to clear */ }
      mountStats(el); // re-render fresh (now shows the empty state)
    });
    wrap.appendChild(resetBtn);
  }

  function typeLabel(view) {
    // view is the source view that logged the session: 'practice' | 'test' | 'review' | ...
    if (view === 'test') return 'test';
    if (view === 'review') return 'review';
    return 'practice';
  }

  function lessonDrillLabel(s) {
    // Session.lesson may be an index or a title string; resolve via TMData when numeric.
    var lessons = (window.TMData && Array.isArray(window.TMData.lessons)) ? window.TMData.lessons : [];
    var lessonTxt;
    if (typeof s.lesson === 'number' && lessons[s.lesson]) {
      lessonTxt = lessons[s.lesson].title || ('Lesson ' + (s.lesson + 1));
    } else if (s.lesson !== undefined && s.lesson !== null && s.lesson !== '') {
      lessonTxt = String(s.lesson);
    } else if (s.durationSec) {
      lessonTxt = fmtTime(s.durationSec) + ' test';
    } else {
      lessonTxt = '—';
    }
    var drillTxt = '';
    if (typeof s.drill === 'number' && typeof s.lesson === 'number' &&
        lessons[s.lesson] && Array.isArray(lessons[s.lesson].drills) &&
        lessons[s.lesson].drills[s.drill]) {
      drillTxt = lessons[s.lesson].drills[s.drill].title || ('Drill ' + (s.drill + 1));
    } else if (s.drill !== undefined && s.drill !== null && s.drill !== '') {
      drillTxt = String(s.drill);
    }
    return drillTxt ? (lessonTxt + ' — ' + drillTxt) : lessonTxt;
  }

  TM.registerView('stats', { mount: mountStats, unmount: statsUnmount });

  // ------------------------------------------------------ 'review' view

  // Small built-in neutral word list; the drill keeps only words containing at
  // least one weak key, so practice is concentrated on problem keys.
  var REVIEW_WORDS = [
    'the', 'and', 'for', 'with', 'you', 'that', 'have', 'this', 'from', 'they',
    'time', 'word', 'type', 'fast', 'slow', 'key', 'hand', 'finger', 'home', 'row',
    'learn', 'skill', 'drill', 'focus', 'quick', 'brown', 'fox', 'jumps', 'over', 'lazy',
    'dog', 'pack', 'box', 'jazz', 'quiz', 'water', 'light', 'night', 'day', 'sun'
  ];
  var REVIEW_SENTENCE_TPL = [
    'Keep your fingers on the home row and type steadily.',
    'Accuracy first, speed will follow with daily practice.',
    'Watch the screen, not the keyboard, while you type.',
    'Relax your shoulders and keep a steady rhythm.'
  ];

  function pickWeakKeys(keyErrors) {
    var entries = Object.keys(keyErrors || {}).map(function (k) {
      return { ch: k, count: num(keyErrors[k]) };
    }).filter(function (e) { return e.count > 0 && e.ch && e.ch.length === 1; });
    entries.sort(function (a, b) {
      if (b.count !== a.count) return b.count - a.count; // most errors first
      return a.ch < b.ch ? -1 : (a.ch > b.ch ? 1 : 0);    // tie-break: alphabetical
    });
    return entries.slice(0, 8).map(function (e) { return e.ch; });
  }

  function buildReviewText(weakKeys) {
    // Deterministic drill from weak keys: key-pair sequences, filtered words,
    // then a few neutral sentences. Seeded by the weak-key chars.
    var seed = weakKeys.reduce(function (a, c) { return a + c.charCodeAt(0) * 31; }, 7);
    var rand = seededRand(seed);
    function pick(arr) { return arr[Math.floor(rand() * arr.length)]; }
    var parts = [];

    // 1) Key-pair / triplet sequences: "as as sa sa ..."
    var pairs = [];
    for (var i = 0; i < 12; i++) {
      var a = pick(weakKeys), b = pick(weakKeys);
      pairs.push(a + b);
    }
    parts.push(pairs.join(' '));

    // 2) Words containing at least one weak key; fallback to key-group sequences.
    var weakSet = {};
    weakKeys.forEach(function (c) { weakSet[c.toLowerCase()] = true; });
    var words = REVIEW_WORDS.filter(function (w) {
      for (var j = 0; j < w.length; j++) if (weakSet[w[j]]) return true;
      return false;
    });
    var wordBits = [];
    if (words.length) {
      for (var k = 0; k < 24; k++) wordBits.push(pick(words));
    } else {
      for (var m = 0; m < 24; m++) {
        var grp = '';
        for (var n = 0; n < 4; n++) grp += pick(weakKeys);
        wordBits.push(grp);
      }
    }
    parts.push(wordBits.join(' '));

    // 3) A couple of neutral sentences for flowing text.
    parts.push(REVIEW_SENTENCE_TPL.slice(0, 2).join(' '));

    return parts.join('  ');
  }

  var reviewStop = null; // stop() handle from TM.Engine.startCustom

  function mountReview(el, params) {
    el.innerHTML = '';
    var wrap = mk('div', 'tm-review');
    el.appendChild(wrap);
    wrap.appendChild(mk('h2', 'tm-view-title', 'Review weak keys'));

    var keyErrors = load('keyErrors', {}) || {};
    var weakKeys = pickWeakKeys(keyErrors);

    if (!weakKeys.length) {
      wrap.appendChild(mk('p', 'tm-empty',
        'Type some drills first — Review builds a custom drill from your weakest keys.'));
      var goBtn = mk('button', 'tm-btn', 'Go to course');
      goBtn.type = 'button';
      goBtn.addEventListener('click', function () {
        // Navigate back to the course view through the app router if exposed.
        try {
          if (TM.showView) TM.showView('course');
          else if (TM.navigate) TM.navigate('course');
          else window.location.hash = '#/course';
        } catch (e) { window.location.hash = '#/course'; }
      });
      wrap.appendChild(goBtn);
      return;
    }

    // Weak-key chips.
    var chips = mk('div', 'tm-chips');
    chips.appendChild(mk('span', 'tm-chips-label', 'Your weakest keys:'));
    weakKeys.forEach(function (c) {
      chips.appendChild(mk('span', 'tm-chip', esc(c)));
    });
    wrap.appendChild(chips);

    // Drill host element for the engine.
    var drillHost = mk('div', 'tm-review-drill');
    wrap.appendChild(drillHost);

    if (!window.TM || !window.TM.Engine || typeof window.TM.Engine.startCustom !== 'function') {
      drillHost.appendChild(mk('p', 'tm-empty',
        'The typing engine is not available right now. Please reload the page and try again.'));
      return;
    }

    var text = buildReviewText(weakKeys);
    try {
      reviewStop = window.TM.Engine.startCustom(drillHost, text, 'Review drill');
    } catch (e) {
      reviewStop = null;
      drillHost.appendChild(mk('p', 'tm-empty', 'Could not start the review drill: ' + esc(e && e.message ? e.message : e)));
    }
    // Note: TM.Engine.startCustom logs the completed session via
    // TM.appendSession / TM.recordKeyErrors internally per the shared contract.
  }

  function unmountReview() {
    // Stop the active custom drill so its timers/listeners are released.
    if (typeof reviewStop === 'function') {
      try { reviewStop(); } catch (e) { /* already stopped */ }
      reviewStop = null;
    }
  }

  TM.registerView('review', { mount: mountReview, unmount: unmountReview });

})();
