/* data.js — lesson/drill definitions + deterministic drill-text generation.
 * Loaded AFTER app.js (window.TM contract). Defines window.TMData.
 * Vanilla JS, no external requests, works from file://.
 */
(function () {
  'use strict';

  /* ---- Seeded RNG (mulberry32) ----
   * Deterministic: same seed always yields the same sequence, so a drill's
   * text is stable for a given (lesson, drill, attempt). A mid-drill page
   * refresh re-renders identical text for the same attempt number. */
  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ---- Word bank (~140 common, neutral, lowercase words) ----
   * Used for word/sentence drills; filtered per lesson to words that can be
   * built from the keys learned so far. */
  var WORDS = (
    'the and for are with they this have from one had word but what some can out ' +
    'other were which their time will about many then them would like these long ' +
    'make thing see two look more day could come did number sound most people ' +
    'over know water than call first down side been find head stand page should ' +
    'found answer school grow study still learn plant cover food four keep never ' +
    'last thought city tree cross farm hard start might story left late while ' +
    'press close night real life north open next white walk ease paper group ' +
    'always music both mark often letter until mile river feet care second book ' +
    'carry took eat room friend began idea hear cut sure watch color face wood ' +
    'main plain young ready above ever list though feel talk bird soon body dog ' +
    'door black short class wind happen half rock order fire south piece hour ' +
    'knew pass since whole best early hold west ground under along small every ' +
    'place year live where after well also play small work such even new must big ' +
    'same tell does set want air try kind hand high every old great men read need ' +
    'land here home move try kind'
  ).split(' ').filter(Boolean);
  // de-duplicate just in case
  WORDS = WORDS.filter(function (w, i) { return WORDS.indexOf(w) === i; });

  /* ---- The 12 lessons. Exactly 5 drills each, kinds in fixed order. ---- */
  var DRILL_KINDS = ['newkeys', 'keydrill', 'worddrill', 'sentence', 'review'];
  var DRILL_TITLES = ['New keys', 'Key drill', 'Word drill', 'Sentence drill', 'Review'];

  function makeDrills(lessonIdx) {
    return DRILL_KINDS.map(function (kind, i) {
      return { id: 'l' + (lessonIdx + 1) + '-' + kind, title: DRILL_TITLES[i], kind: kind };
    });
  }

  var LESSON_DEFS = [
    { title: 'Lesson 1',  subtitle: 'Home row',            keys: 'asdfjkl;' },
    { title: 'Lesson 2',  subtitle: 'E, I, R, U',          keys: 'eiru' },
    { title: 'Lesson 3',  subtitle: 'H, G, O, N',          keys: 'hgon' },
    { title: 'Lesson 4',  subtitle: 'T, W, B, P',          keys: 'twbp' },
    { title: 'Lesson 5',  subtitle: 'Y, V, X, C',          keys: 'yvxc' },
    { title: 'Lesson 6',  subtitle: 'Z, M and punctuation', keys: 'zm,./' },
    { title: 'Lesson 7',  subtitle: 'Shift & capitals',     keys: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', shifts: true },
    { title: 'Lesson 8',  subtitle: 'Numbers',              keys: '0123456789' },
    { title: 'Lesson 9',  subtitle: 'Symbols',              keys: '!@#$%^&*()_+-=[]{};:\'",.<>/?|`~' },
    { title: 'Lesson 10', subtitle: 'Word drill',           keys: 'abcdefghijklmnopqrstuvwxyz' },
    { title: 'Lesson 11', subtitle: 'Sentence drill',       keys: 'abcdefghijklmnopqrstuvwxyz' },
    { title: 'Lesson 12', subtitle: 'Full review & speed',  keys: 'abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{};:\'",.<>/?|`~' }
  ];

  var lessons = LESSON_DEFS.map(function (def, i) {
    return {
      title: def.title,
      subtitle: def.subtitle,
      keys: def.keys,
      shifts: !!def.shifts,
      drills: makeDrills(i)
    };
  });

  /* Cumulative key set: all keys from lessons 1..N (1-based N), de-duplicated,
   * order preserved. Used by keydrill/worddrill so drills reinforce old keys. */
  function cumulativeKeys(uptoLesson1Based) {
    var seen = {}, out = '';
    for (var i = 0; i < uptoLesson1Based && i < lessons.length; i++) {
      var ks = lessons[i].keys;
      for (var j = 0; j < ks.length; j++) {
        var c = ks[j];
        if (!seen[c]) { seen[c] = true; out += c; }
      }
    }
    return out;
  }

  /* Attempt counter: variety between runs of the same drill. Kept in a local
   * var (NOT localStorage) so it is session-scoped; drill text stays
   * deterministic per (lesson, drill, attempt). */
  var attempt = 0;
  function newAttempt() { attempt += 1; return attempt; }
  function getAttempt() { return attempt; }

  /* ---- small helpers ---- */
  function pick(rng, arr) { return arr[Math.floor(rng() * arr.length)]; }
  function pickChar(rng, str) { return str.charAt(Math.floor(rng() * str.length)); }

  /* Random groups of 2-3 keys, space-separated: "as dfd jkl". */
  function keyGroups(rng, keyStr, targetLen) {
    var groups = [];
    var len = 0;
    while (len < targetLen) {
      var n = 2 + Math.floor(rng() * 2); // 2 or 3
      var g = '';
      for (var i = 0; i < n; i++) g += pickChar(rng, keyStr);
      groups.push(g);
      len += n + 1;
    }
    return groups.join(' ');
  }

  /* Random character stream (single chars, occasional spaces). */
  function keyStream(rng, keyStr, targetLen) {
    var s = '';
    while (s.length < targetLen) {
      if (rng() < 0.12) s += ' ';
      else s += pickChar(rng, keyStr);
    }
    return s.replace(/ {2,}/g, ' ').trim();
  }

  function canBuild(word, keySet) {
    for (var i = 0; i < word.length; i++) {
      if (keySet.indexOf(word[i]) === -1) return false;
    }
    return true;
  }

  /* Pronounceable fallback syllables from the learned keys, e.g. "sa", "fel". */
  function syllable(rng, vowels, consonants) {
    var v = function () { return pickChar(rng, vowels); };
    var c = function () { return pickChar(rng, consonants); };
    var kind = Math.floor(rng() * 4);
    if (kind === 0) return c() + v();
    if (kind === 1) return v() + c();
    if (kind === 2) return c() + v() + c();
    return v() + c() + v();
  }

  function wordLine(rng, words, perLine) {
    var ws = [];
    for (var i = 0; i < perLine; i++) ws.push(pick(rng, words));
    return ws.join(' ');
  }

  function sentenceFrom(rng, words) {
    var n = 5 + Math.floor(rng() * 4); // 5-8 words
    var ws = [];
    for (var i = 0; i < n; i++) ws.push(pick(rng, words));
    var s = ws.join(' ');
    return s.charAt(0).toUpperCase() + s.slice(1) + '.';
  }

  /* Clamp total chars into [200, 450]: drop trailing lines if too long,
   * append more lines (via gen) if too short. */
  function fit(lines, genMore) {
    while (lines.join('\n').length > 450 && lines.length > 1) lines.pop();
    var guard = 0;
    while (lines.join('\n').length < 200 && guard++ < 20) lines.push(genMore());
    return lines.join('\n');
  }

  /* ---- drill generators (each returns an array of lines) ---- */

  function genNewkeys(rng, lesson) {
    var keys = lesson.keys;
    // Lessons 10-12 are word/sentence/review lessons: newkeys drill uses letters
    // (or the full charset for lesson 12) instead of re-introducing keys.
    var lines = [];
    for (var i = 0; i < 3; i++) lines.push(keyGroups(rng, keys, 60));
    return lines;
  }

  function genKeydrill(rng, lessonIdx) {
    var cum = cumulativeKeys(lessonIdx + 1);
    var lines = [];
    for (var i = 0; i < 4; i++) {
      // mix: sometimes grouped, sometimes a raw stream
      lines.push(rng() < 0.5 ? keyGroups(rng, cum, 58) : keyStream(rng, cum, 58));
    }
    return lines;
  }

  function genWorddrill(rng, lessonIdx) {
    var cumLower = cumulativeKeys(lessonIdx + 1).toLowerCase();
    var pool;
    if (lessonIdx >= 6) {
      pool = WORDS.slice(); // lessons 7-12: full word bank
    } else {
      pool = WORDS.filter(function (w) { return canBuild(w, cumLower); });
    }
    var useSyllables = pool.length < 25;
    var vowels = '', consonants = '';
    if (useSyllables) {
      for (var i = 0; i < cumLower.length; i++) {
        var c = cumLower[i];
        if (c < 'a' || c > 'z') continue;
        if ('aeiou'.indexOf(c) !== -1) vowels += c; else consonants += c;
      }
      if (!vowels) vowels = 'a';
      if (!consonants) consonants = 't';
    }
    var lines = [];
    for (var l = 0; l < 6; l++) {
      if (useSyllables) {
        var ws = [];
        for (var k = 0; k < 9; k++) ws.push(syllable(rng, vowels, consonants));
        lines.push(ws.join(' '));
      } else {
        lines.push(wordLine(rng, pool, 9));
      }
    }
    return lines;
  }

  function genSentence(rng, lessonIdx) {
    var cumLower = cumulativeKeys(lessonIdx + 1).toLowerCase();
    var pool;
    if (lessonIdx >= 6) {
      pool = WORDS.slice();
    } else {
      pool = WORDS.filter(function (w) { return canBuild(w, cumLower); });
      if (pool.length < 25) {
        // not enough real words yet: fall back to plain word lines
        return genWorddrill(rng, lessonIdx).slice(0, 5);
      }
    }
    var lines = [];
    for (var i = 0; i < 5; i++) {
      // one or two sentences per line for variety
      var line = sentenceFrom(rng, pool);
      if (rng() < 0.5) line += ' ' + sentenceFrom(rng, pool);
      lines.push(line);
    }
    return lines;
  }

  function genReview(rng, lessonIdx) {
    // mix of everything: key groups, words, sentences
    var wordLines = genWorddrill(rng, lessonIdx);
    var sentLines = genSentence(rng, lessonIdx);
    var keyLines = genKeydrill(rng, lessonIdx);
    var lines = [];
    var order = [0, 1, 2, 3, 4, 5, 6, 7];
    // deterministic shuffle of the 8 line slots
    for (var i = order.length - 1; i > 0; i--) {
      var j = Math.floor(rng() * (i + 1));
      var t = order[i]; order[i] = order[j]; order[j] = t;
    }
    for (var k = 0; k < 8; k++) {
      var slot = order[k];
      if (slot < 3) lines.push(keyLines[slot % keyLines.length]);
      else if (slot < 6) lines.push(wordLines[slot % wordLines.length]);
      else lines.push(sentLines[slot % sentLines.length]);
    }
    return lines;
  }

  /* Public: build the drill text for (lessonIdx, drillIdx) at the current
   * attempt. seed = lessonIdx*100 + drillIdx, offset per attempt. */
  function makeDrill(lessonIdx, drillIdx, seedOverride) {
    var lesson = lessons[lessonIdx];
    var kind = lesson.drills[drillIdx].kind;
    var seed = (typeof seedOverride === 'number')
      ? seedOverride
      : (lessonIdx * 100 + drillIdx + attempt * 7919);
    var rng = mulberry32(seed);
    var lines;
    if (kind === 'newkeys') lines = genNewkeys(rng, lesson);
    else if (kind === 'keydrill') lines = genKeydrill(rng, lessonIdx);
    else if (kind === 'worddrill') lines = genWorddrill(rng, lessonIdx);
    else if (kind === 'sentence') lines = genSentence(rng, lessonIdx);
    else lines = genReview(rng, lessonIdx);

    var genMore;
    if (kind === 'newkeys') genMore = function () { return keyGroups(rng, lesson.keys, 60); };
    else if (kind === 'keydrill') genMore = function () { return keyStream(rng, cumulativeKeys(lessonIdx + 1), 58); };
    else if (kind === 'worddrill') genMore = function () { return genWorddrill(rng, lessonIdx)[0]; };
    else if (kind === 'sentence') genMore = function () { return genSentence(rng, lessonIdx)[0]; };
    else genMore = function () { return genReview(rng, lessonIdx)[0]; };

    return fit(lines, genMore);
  }

  window.TMData = {
    version: 1,
    lessons: lessons,
    makeDrill: makeDrill,
    newAttempt: newAttempt,
    getAttempt: getAttempt,
    cumulativeKeys: cumulativeKeys,
    wordCount: WORDS.length
  };
})();
